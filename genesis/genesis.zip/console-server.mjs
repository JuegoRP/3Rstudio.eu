// GENESIS Director Console — lokální server.
// Obsluhuje hru (statické soubory) + endpoint /api/rewrite:
//   věta od hráče + aktuální ústava  ->  LLM  ->  nová ústava  ->  VALIDACE  ->  zápis
// Tohle je "AI vrstva" z manifestu: netechnik píše záměr, svět se mění.
// Klíč se bere z prostředí (GENESIS_KEY), nikam se neukládá.
import http from "http";
import fs from "fs";
import path from "path";
import { spawn } from "child_process";
import { fileURLToPath } from "url";

const KOREN = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 8642;
const KEY = process.env.GENESIS_KEY || "";
const PROVIDER = process.env.GENESIS_PROVIDER || (KEY.startsWith("sk-ant") ? "anthropic" : "openai");
const MODEL = process.env.GENESIS_MODEL || (PROVIDER === "anthropic" ? "claude-sonnet-5" : "gpt-4o");

const MIME = { ".html": "text/html", ".js": "text/javascript", ".json": "application/json", ".css": "text/css", ".mjs": "text/javascript" };

const server = http.createServer(async (req, res) => {
  if (req.method === "POST" && req.url === "/api/rewrite") return rewrite(req, res);
  if (req.method === "GET" && req.url === "/api/status")
    return posli(res, 200, { provider: KEY ? PROVIDER : null, model: KEY ? MODEL : null, klic: !!KEY });
  // statické soubory
  let rel = decodeURIComponent(req.url.split("?")[0]);
  if (rel === "/") rel = "/index.html";
  const soubor = path.join(KOREN, path.normalize(rel));
  if (!soubor.startsWith(KOREN)) { res.writeHead(403); return res.end(); }
  fs.readFile(soubor, (err, data) => {
    if (err) { res.writeHead(404); return res.end("404"); }
    res.writeHead(200, { "Content-Type": MIME[path.extname(soubor)] || "application/octet-stream" });
    res.end(data);
  });
});

function posli(res, kod, obj) {
  res.writeHead(kod, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(obj));
}

function telo(req) {
  return new Promise(r => { let s = ""; req.on("data", d => s += d); req.on("end", () => r(s)); });
}

async function rewrite(req, res) {
  let vstup;
  try { vstup = JSON.parse(await telo(req)); } catch { return posli(res, 400, { ok: false, chyba: "Špatný požadavek." }); }
  const veta = (vstup.veta || "").trim();
  if (!veta) return posli(res, 400, { ok: false, chyba: "Prázdná věta." });

  // BYOK: klíč a provider z požadavku (uživatelův) mají přednost; jinak serverový (env)
  const klic = vstup.klic || KEY;
  const provider = vstup.provider || PROVIDER;
  const model = vstup.model || (provider === "server" ? MODEL : null);
  if (!klic) return posli(res, 400, { ok: false, chyba: "Bez API klíče. Nastav svůj klíč (Nastavení AI) nebo spusť ./console.sh." });

  const ustava = fs.readFileSync(path.join(KOREN, "rules.json"), "utf8");
  let novaUstava;
  try {
    novaUstava = await zavolejLLM(veta, ustava, provider, klic, model);
  } catch (e) {
    return posli(res, 502, { ok: false, chyba: "AI nedostupná: " + e.message });
  }

  // validace nasucho — když je svět rozbitý, změnu NEZAPÍŠEME
  const vysledek = await validuj(novaUstava);
  if (!vysledek.ok) {
    return posli(res, 200, { ok: false, chyba: "Návrh by svět rozbil — nezapsáno.", detail: vysledek.chyby, navrh: novaUstava });
  }

  // diff-safety: co věta smazala? Když velké tiché mazání, NEzapíšeme bez potvrzení.
  const zmeny = rozdil(ustava, novaUstava);
  if (!vstup.potvrdit && zmeny.riziko) {
    return posli(res, 200, { ok: false, cekaPotvrzeni: true, navrh: novaUstava,
      chyba: "Pozor — tahle věta by smazala: " + zmeny.smazano.join(", ") + ". Zapsat i tak?", zmeny });
  }

  // časově verzovaná historie ústavy (ne jen jeden backup)
  const hist = path.join(KOREN, "rules-historie");
  try { fs.mkdirSync(hist, { recursive: true }); fs.copyFileSync(path.join(KOREN, "rules.json"), path.join(hist, "rules-" + Date.now() + ".json")); } catch {}
  fs.copyFileSync(path.join(KOREN, "rules.json"), path.join(KOREN, "rules.bak.json"));
  fs.writeFileSync(path.join(KOREN, "rules.json"), novaUstava);
  posli(res, 200, { ok: true, varovani: vysledek.varovani, souhrn: vysledek.souhrn, zmeny });
}

// porovná starou a novou ústavu; hlásí, co přibylo/zmizelo, a označí rizikové mazání
function rozdil(staraText, novaText) {
  let a, b;
  try { a = JSON.parse(staraText); b = JSON.parse(novaText); } catch { return { pridano: [], smazano: [], riziko: false }; }
  const pridano = [], smazano = [];
  const porovnej = (sekce, popis) => {
    const sa = a[sekce], sb = b[sekce];
    if (!sa) return;
    const klic = Array.isArray(sa) ? o => o.id : null;
    const kA = Array.isArray(sa) ? sa.map(klic) : Object.keys(sa || {});
    const kB = Array.isArray(sb) ? (sb || []).map(klic) : Object.keys(sb || {});
    const setB = new Set(kB);
    for (const k of kA) if (k != null && !setB.has(k)) smazano.push(popis + " „" + k + "“");
    const setA = new Set(kA);
    for (const k of kB) if (k != null && !setA.has(k)) pridano.push(popis + " „" + k + "“");
  };
  porovnej("materialy", "materiál");
  porovnej("zakony", "zákon");
  porovnej("bytosti", "bytost");
  // rizikové = smazalo víc než přidalo a smazalo aspoň 2 věci (typicky nechtěné)
  const riziko = smazano.length >= 2 && smazano.length > pridano.length;
  return { pridano, smazano, riziko };
}

function validuj(text) {
  return new Promise(r => {
    const p = spawn(process.execPath, [path.join(KOREN, "validate.mjs")]);
    let out = "";
    p.stdout.on("data", d => out += d);
    p.on("close", () => { try { r(JSON.parse(out)); } catch { r({ ok: false, chyby: ["Validátor selhal."] }); } });
    p.stdin.write(text); p.stdin.end();
  });
}

const SYSTEM = `Jsi Director Console herního enginu GENESIS. Svět je plně popsán jediným JSON souborem (ústavou): materiály s vlastnostmi, zákony (kdyz/cil/pokud/sance/udelej), bytosti, povolání, dovednosti a questy. Hra je jen interpret těchto dat.

Dostaneš AKTUÁLNÍ ústavu a přání hráče přirozeným jazykem. Vrať CELOU novou ústavu jako platný JSON — nic jiného, žádný markdown, žádné vysvětlení. Zachovej vše, co hráč nechtěl měnit. Drž se přesně existujícího schématu a konvencí (české klíče: nazev, barva, vlastnosti, palivo; zákony mají id, popis, kdyz, cil, udelej; efekty: pridejStav/odeberStav/zmenVar/nastavVar/promenNa/log). Nové chování skládej z existujících stavebních bloků a vlastností. Barvy jako #rrggbb. Když hráč přidává materiál, dej mu smysluplné vlastnosti, ať funguje se stávajícími zákony (horlave/vodive/schudne/kapalne/pevne/organicke/drevene).`;

// výchozí modely per provider (uživatel může přebít vlastním)
const VYCHOZI_MODEL = { anthropic: "claude-sonnet-5", openai: "gpt-4o", gemini: "gemini-2.0-flash", deepseek: "deepseek-chat", server: MODEL };

async function zavolejLLM(veta, ustava, provider, klic, model) {
  const zprava = "AKTUÁLNÍ ÚSTAVA:\n" + ustava + "\n\nPŘÁNÍ HRÁČE:\n" + veta + "\n\nVrať celou novou ústavu jako čistý JSON.";
  const m = model || VYCHOZI_MODEL[provider] || VYCHOZI_MODEL[PROVIDER];
  const p = provider === "server" ? PROVIDER : provider;

  if (p === "anthropic") {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": klic, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: m, max_tokens: 8000, system: SYSTEM, messages: [{ role: "user", content: zprava }] })
    });
    if (!r.ok) throw new Error("HTTP " + r.status + " " + (await r.text()).slice(0, 200));
    const j = await r.json();
    return vytahniJSON(j.content.map(c => c.text || "").join(""));
  }
  if (p === "gemini") {
    const r = await fetch("https://generativelanguage.googleapis.com/v1beta/models/" + m + ":generateContent?key=" + encodeURIComponent(klic), {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ systemInstruction: { parts: [{ text: SYSTEM }] }, contents: [{ parts: [{ text: zprava }] }], generationConfig: { responseMimeType: "application/json" } })
    });
    if (!r.ok) throw new Error("HTTP " + r.status + " " + (await r.text()).slice(0, 200));
    const j = await r.json();
    return vytahniJSON(j.candidates[0].content.parts.map(x => x.text || "").join(""));
  }
  // openai i deepseek jsou OpenAI-kompatibilní, liší se jen URL
  const url = p === "deepseek" ? "https://api.deepseek.com/chat/completions" : "https://api.openai.com/v1/chat/completions";
  const body = { model: m, messages: [{ role: "system", content: SYSTEM }, { role: "user", content: zprava }] };
  if (p === "openai") body.response_format = { type: "json_object" };
  const r = await fetch(url, { method: "POST", headers: { "content-type": "application/json", "authorization": "Bearer " + klic }, body: JSON.stringify(body) });
  if (!r.ok) throw new Error("HTTP " + r.status + " " + (await r.text()).slice(0, 200));
  const j = await r.json();
  return vytahniJSON(j.choices[0].message.content);
}

function vytahniJSON(text) {
  let t = text.trim();
  if (t.startsWith("```")) t = t.replace(/^```[a-z]*\n?/, "").replace(/```\s*$/, "");
  const a = t.indexOf("{"), b = t.lastIndexOf("}");
  if (a >= 0 && b > a) t = t.slice(a, b + 1);
  JSON.parse(t); // ať to spadne tady, ne až u hráče
  return t;
}

server.listen(PORT, "127.0.0.1", () => {
  console.log("GENESIS Director Console na http://localhost:" + PORT);
  console.log(KEY ? ("AI: " + PROVIDER + " / " + MODEL) : "AI: VYPNUTA (bez klíče — hra funguje, konzole ne)");
});

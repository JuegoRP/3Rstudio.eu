"use strict";
// ============================================================
// GENESIS ASSETS — úložiště AI-generovaných obrázků/zvuků.
// Vedlejší vrstva klíčovaná jménem (mat:lava, bytost:Drak, …).
// Renderery se ptají: „mám asset pro tenhle materiál?" — když ano,
// použijí texturu; když ne, spadnou zpět na barvu/emoji z ústavy.
// Ústava tak nemusí vědět o obrázcích. IndexedDB (velké, offline).
// ============================================================
const GenesisAssets = (function () {
  let dbP = null;
  function db() {
    if (!dbP) dbP = new Promise((res, rej) => {
      const r = indexedDB.open("genesis_assets", 1);
      r.onupgradeneeded = e => { if (!e.target.result.objectStoreNames.contains("a")) e.target.result.createObjectStore("a"); };
      r.onsuccess = e => res(e.target.result);
      r.onerror = () => rej(r.error);
    });
    return dbP;
  }
  async function uloz(klic, dataUrl) {
    const d = await db();
    return new Promise((res, rej) => { const t = d.transaction("a", "readwrite"); t.objectStore("a").put(dataUrl, klic); t.oncomplete = () => { delete cache[klic]; res(); }; t.onerror = () => rej(t.error); });
  }
  async function nacti(klic) {
    const d = await db();
    return new Promise(res => { const r = d.transaction("a").objectStore("a").get(klic); r.onsuccess = () => res(r.result || null); r.onerror = () => res(null); });
  }
  async function seznam() {
    const d = await db();
    return new Promise(res => { const r = d.transaction("a").objectStore("a").getAllKeys(); r.onsuccess = () => res(r.result || []); r.onerror = () => res([]); });
  }
  async function smaz(klic) {
    const d = await db();
    return new Promise(res => { const t = d.transaction("a", "readwrite"); t.objectStore("a").delete(klic); t.oncomplete = () => { delete cache[klic]; res(); }; });
  }

  // synchronní cache Image objektů pro renderery (canvas/three).
  // vrací Image (hotový) nebo null; při prvním dotazu spustí načtení a zavolá poHotovu.
  const cache = {};   // klic -> Image | "loading" | "none"
  function obrazek(klic, poHotovu) {
    const c = cache[klic];
    if (c instanceof Image) return c.__ok ? c : null;
    if (c === "loading" || c === "none") return null;
    cache[klic] = "loading";
    nacti(klic).then(dataUrl => {
      if (!dataUrl) { cache[klic] = "none"; return; }
      const img = new Image();
      img.onload = () => { img.__ok = true; cache[klic] = img; if (poHotovu) poHotovu(klic, img); };
      img.onerror = () => { cache[klic] = "none"; };
      img.src = dataUrl;
    });
    return null;
  }
  function zapomen(klic) { delete cache[klic]; }

  return { uloz, nacti, seznam, smaz, obrazek, zapomen };
})();

if (typeof module !== "undefined") module.exports = GenesisAssets;

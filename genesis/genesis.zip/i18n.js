"use strict";
// ============================================================
// GENESIS I18N — jazyky. Výchozí ANGLIČTINA, každý si přepne.
// t("klíč") vrátí text v aktuálním jazyce (fallback → angličtina → klíč).
// Jazyk se drží v prohlížeči. Nové jazyky = jen další objekt v PREKLADY.
// ============================================================
const GenesisI18n = (function () {
  const PREKLADY = {
    en: {
      _nazev: "English",
      // hub
      hub_tagline: "A simulation engine where the world doesn't run on code, but on a <b>constitution</b> (rules.json). One core (core.js) — arbitrarily many different games and simulations on top of it.",
      hub_open_studio: "◈ Open Genesis Studio",
      hub_open_ai: "◈ AI Orchestrator",
      hub_studio_sub: "Studio = IDE over the engine · Orchestrator = multi-modal creation (text/images/voice, your own keys)",
      hub_codex_tag: "Flagship game · RPG preset",
      hub_codex_desc: "Infinite survival world like Earth — biomes, mining, crafting, armor, villages with NPCs, day cycle, combat. A character you control. Same world in three views + a turn-based card arena.",
      hub_eko_tag: "Second prototype · proof of the core",
      hub_eko_desc: "A completely different simulation on the <b>same core</b>: no hero, no combat. Grass grows, hares graze and multiply, foxes hunt hares — and populations oscillate like in nature. Turn on drought and watch the collapse. Built without a single change to core.js.",
      hub_life_tag: "Third preset · onboarding",
      hub_life_desc: "The simplest world on the core — Conway's Game of Life in <b>three laws</b>. In five minutes you'll grasp how complexity arises from a few rules. Click cells, start time, place a glider. Proved the core handles cellular automata too (synchronous step, neighbor counting).",
      hub_run: "Run",
      hub_run_eko: "Run ecosystem",
      hub_run_life: "Run Game of Life",
      hub_arch: "<b>Architecture:</b> <code>core.js</code> = generic engine (chunked world, RNG/noise, law interpreter, hooks) — knows nothing about DOM or any specific game.<br>Each game = its own <code>rules.json</code> (constitution) + a thin renderer + optional game modules. Project CODEX and the Ecosystem share the core, differing only in constitution and renderer.",
      lang_label: "language"
    },
    cs: {
      _nazev: "Čeština",
      hub_tagline: "Simulační engine, kde svět neběží na kódu, ale na <b>ústavě</b> (rules.json). Jedno jádro (core.js) — libovolně mnoho různých her a simulací nad ním.",
      hub_open_studio: "◈ Otevřít Genesis Studio",
      hub_open_ai: "◈ AI Orchestrátor",
      hub_studio_sub: "Studio = IDE nad enginem · Orchestrátor = multi-modální tvorba (text/obrázky/hlas, vlastní klíče)",
      hub_codex_tag: "Vlajková hra · preset RPG",
      hub_codex_desc: "Nekonečný survival svět jako Země — biomy, těžba, výroba, zbroj, vesnice s NPC, denní cyklus, souboje. Postava, kterou ovládáš. Tentýž svět ve třech pohledech + tahová karetní aréna.",
      hub_eko_tag: "Druhý prototyp · důkaz jádra",
      hub_eko_desc: "Úplně jiná simulace nad <b>týmž jádrem</b>: žádný hrdina, žádné souboje. Tráva roste, zajíci ji spásají a množí se, lišky loví zajíce — a populace samy oscilují jako v přírodě. Zapni sucho a sleduj kolaps. Postaveno bez jediného zásahu do core.js.",
      hub_life_tag: "Třetí preset · onboarding",
      hub_life_desc: "Nejjednodušší svět nad jádrem — Conwayova Hra života ve <b>třech zákonech</b>. Za pět minut pochopíš, jak z pár pravidel vzniká složitost. Klikni buňky, spusť čas, polož glider. Ukázalo, že jádro umí i celulární automaty (synchronní krok, počítání sousedů).",
      hub_run: "Spustit",
      hub_run_eko: "Spustit ekosystém",
      hub_run_life: "Spustit Game of Life",
      hub_arch: "<b>Architektura:</b> <code>core.js</code> = generický engine (svět po chuncích, RNG/šum, interpret zákonů, hooky) — nezná DOM ani žádnou konkrétní hru.<br>Každá hra = vlastní <code>rules.json</code> (ústava) + tenký renderer + volitelné herní moduly. Project CODEX i Ekosystém sdílejí jádro, liší se jen ústavou a rendererem.",
      lang_label: "jazyk"
    }
  };

  let jazyk = "en";
  try { const u = localStorage.getItem("genesis_jazyk"); if (u && PREKLADY[u]) jazyk = u; } catch {}

  function t(klic) { return (PREKLADY[jazyk] && PREKLADY[jazyk][klic]) || PREKLADY.en[klic] || klic; }
  function setJazyk(j) { if (PREKLADY[j]) { jazyk = j; try { localStorage.setItem("genesis_jazyk", j); } catch {} } }
  function jazyk_() { return jazyk; }
  function jazyky() { return Object.keys(PREKLADY).map(k => [k, PREKLADY[k]._nazev]); }
  // projde DOM a doplní texty tam, kde je data-i18n="klíč"
  function pouzij(root) {
    (root || document).querySelectorAll("[data-i18n]").forEach(el => { el.innerHTML = t(el.getAttribute("data-i18n")); });
  }

  return { t, setJazyk, jazyk: jazyk_, jazyky, pouzij };
})();

if (typeof module !== "undefined") module.exports = GenesisI18n;

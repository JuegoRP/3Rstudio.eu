"use strict";
// ============================================================
// GENESIS AI — multi-modální orchestrátor (client-side, BYOK).
// Nezná žádný server. Každý uživatel má VLASTNÍ klíče (localStorage),
// volání jdou přímo od něj k poskytovateli. Autor serveru/klíč nikdo
// jiný nevyužije. Modality (text/obrázek/hlas/hudba/video) jsou pluginy
// se stejným rozhraním; orchestrátor je řetězí do workflow (jako n8n,
// ale zabudované a bez závislosti na n8n).
//
// CORS: v prohlížeči jdou přímo jen Anthropic a Google (Gemini/Imagen).
// OpenAI/DeepSeek/ElevenLabs/… blokují browser → v zabaleném programu
// (Tauri) je volá nativní vrstva bez CORS; ve webu potřebují relay.
// Modul to pozná a řekne, když volání nejde.
// ============================================================
const GenesisAI = (function () {

  // ---------- katalog služeb: typ → poskytovatel → jak volat ----------
  const SLUZBY = {
    text: {
      popis: "Text / pravidla světa (ústava)",
      provideri: {
        anthropic: { nazev: "Claude (Anthropic)", browser: true, model: "claude-sonnet-5" },
        gemini:    { nazev: "Gemini (Google)",    browser: true, model: "gemini-2.0-flash" },
        openai:    { nazev: "ChatGPT (OpenAI)",   browser: false, model: "gpt-4o" },
        deepseek:  { nazev: "DeepSeek",           browser: false, model: "deepseek-chat" }
      }
    },
    obrazek: {
      popis: "Obrázky / textury / portréty",
      provideri: {
        gemini:    { nazev: "Imagen (Google)",    browser: true, model: "imagen-3.0-generate-002" },
        openai:    { nazev: "DALL·E / gpt-image (OpenAI)", browser: false, model: "gpt-image-1" },
        stability: { nazev: "Stable Diffusion (Stability)", browser: false, model: "core" }
      }
    },
    hlas: {
      popis: "Hlas / dabing / zvuky (TTS)",
      provideri: {
        openai:     { nazev: "OpenAI TTS",  browser: false, model: "tts-1" },
        elevenlabs: { nazev: "ElevenLabs",  browser: false, model: "eleven_multilingual_v2" }
      }
    },
    hudba: {
      popis: "Hudba / podkres (API zatím omezené)",
      provideri: { suno: { nazev: "Suno", browser: false, model: "v4" } }
    },
    video: {
      popis: "Video / animace (drahé, nezralé)",
      provideri: { runway: { nazev: "Runway", browser: false, model: "gen3" } }
    }
  };

  // ---------- BYOK konfigurace (jen v prohlížeči uživatele) ----------
  function nactiKlice() { try { return JSON.parse(localStorage.getItem("genesis_ai_klice") || "{}"); } catch { return {}; } }
  function ulozKlice(k) { localStorage.setItem("genesis_ai_klice", JSON.stringify(k)); }
  function config(typ) { const k = nactiKlice(); return k[typ] || { provider: null, klic: "", model: "" }; }
  function nastav(typ, provider, klic, model) { const k = nactiKlice(); k[typ] = { provider, klic, model: model || "" }; ulozKlice(k); }
  function maKlic(typ) { const c = config(typ); return !!(c.provider && (c.klic || c.provider === "server")); }

  // prostředí: Tauri (nativní HTTP, bez CORS) vs. čistý prohlížeč
  const jeTauri = typeof window !== "undefined" && !!window.__TAURI__;
  function lzeVolat(typ) {
    const c = config(typ); if (!c.provider) return false;
    if (jeTauri) return true;                                   // desktop obchází CORS
    const p = (SLUZBY[typ].provideri[c.provider] || {});
    return !!p.browser;                                          // web: jen browser-friendly
  }

  // ---------- volání jednotlivých modalit ----------
  async function fetchJSON(url, opts) {
    const r = await fetch(url, opts);
    if (!r.ok) throw new Error("HTTP " + r.status + " " + (await r.text()).slice(0, 160));
    return r.json();
  }

  async function volejText(c, system, uziv) {
    const m = c.model || SLUZBY.text.provideri[c.provider].model;
    if (c.provider === "anthropic") {
      const j = await fetchJSON("https://api.anthropic.com/v1/messages", {
        method: "POST", headers: { "content-type": "application/json", "x-api-key": c.klic, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
        body: JSON.stringify({ model: m, max_tokens: 8000, system, messages: [{ role: "user", content: uziv }] }) });
      return j.content.map(x => x.text || "").join("");
    }
    if (c.provider === "gemini") {
      const j = await fetchJSON("https://generativelanguage.googleapis.com/v1beta/models/" + m + ":generateContent?key=" + encodeURIComponent(c.klic), {
        method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({ systemInstruction: { parts: [{ text: system }] }, contents: [{ parts: [{ text: uziv }] }] }) });
      return j.candidates[0].content.parts.map(x => x.text || "").join("");
    }
    // openai / deepseek (OpenAI-kompatibilní)
    const url = c.provider === "deepseek" ? "https://api.deepseek.com/chat/completions" : "https://api.openai.com/v1/chat/completions";
    const j = await fetchJSON(url, { method: "POST", headers: { "content-type": "application/json", "authorization": "Bearer " + c.klic },
      body: JSON.stringify({ model: m, messages: [{ role: "system", content: system }, { role: "user", content: uziv }] }) });
    return j.choices[0].message.content;
  }

  // vrací data URL obrázku (base64) — jednotný výstup napříč providery
  async function volejObrazek(c, prompt) {
    const m = c.model || SLUZBY.obrazek.provideri[c.provider].model;
    if (c.provider === "gemini") {
      const j = await fetchJSON("https://generativelanguage.googleapis.com/v1beta/models/" + m + ":predict?key=" + encodeURIComponent(c.klic), {
        method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({ instances: [{ prompt }], parameters: { sampleCount: 1 } }) });
      return "data:image/png;base64," + j.predictions[0].bytesBase64Encoded;
    }
    if (c.provider === "stability") {
      const fd = new FormData(); fd.append("prompt", prompt); fd.append("output_format", "png");
      const r = await fetch("https://api.stability.ai/v2beta/stable-image/generate/" + m, { method: "POST", headers: { authorization: "Bearer " + c.klic, accept: "image/*" }, body: fd });
      if (!r.ok) throw new Error("HTTP " + r.status);
      const buf = await r.arrayBuffer(); return "data:image/png;base64," + arrToB64(buf);
    }
    // openai images
    const j = await fetchJSON("https://api.openai.com/v1/images/generations", {
      method: "POST", headers: { "content-type": "application/json", "authorization": "Bearer " + c.klic },
      body: JSON.stringify({ model: m, prompt, size: "1024x1024", n: 1 }) });
    return j.data[0].b64_json ? "data:image/png;base64," + j.data[0].b64_json : j.data[0].url;
  }

  async function volejHlas(c, text) {
    const m = c.model || SLUZBY.hlas.provideri[c.provider].model;
    if (c.provider === "elevenlabs") {
      const r = await fetch("https://api.elevenlabs.io/v1/text-to-speech/21m00Tcm4TlvDq8ikWAM", {
        method: "POST", headers: { "xi-api-key": c.klic, "content-type": "application/json" },
        body: JSON.stringify({ text, model_id: m }) });
      if (!r.ok) throw new Error("HTTP " + r.status);
      return "data:audio/mpeg;base64," + arrToB64(await r.arrayBuffer());
    }
    const r = await fetch("https://api.openai.com/v1/audio/speech", {
      method: "POST", headers: { "content-type": "application/json", "authorization": "Bearer " + c.klic },
      body: JSON.stringify({ model: m, voice: "onyx", input: text }) });
    if (!r.ok) throw new Error("HTTP " + r.status);
    return "data:audio/mpeg;base64," + arrToB64(await r.arrayBuffer());
  }
  function arrToB64(buf) { let s = ""; const b = new Uint8Array(buf); for (let i = 0; i < b.length; i++) s += String.fromCharCode(b[i]); return btoa(s); }

  // jednotné volání služby podle typu
  async function zavolej(typ, vstup, opts) {
    if (!lzeVolat(typ)) {
      const c = config(typ);
      throw new Error(c.provider ? ("„" + (SLUZBY[typ].provideri[c.provider] || {}).nazev + "“ nejde volat z prohlížeče (CORS) — potřebuje desktop verzi.") : ("Není nastavená AI služba pro „" + typ + "“."));
    }
    const c = config(typ);
    if (typ === "text") return volejText(c, (opts && opts.system) || "", vstup);
    if (typ === "obrazek") return volejObrazek(c, vstup);
    if (typ === "hlas") return volejHlas(c, vstup);
    throw new Error("Modalita „" + typ + "“ zatím není implementovaná (API nezralé).");
  }

  // ---------- ORCHESTRÁTOR: workflow = řetěz kroků (jako n8n) ----------
  // krok: { sluzba, vstup, ulozJako, system? }. vstup umí {{promenna}} z kontextu.
  function dosad(sablona, ctx) { return String(sablona).replace(/\{\{(\w+)\}\}/g, (_, k) => ctx[k] != null ? ctx[k] : ""); }
  async function spustWorkflow(kroky, kontext, poKroku) {
    const ctx = Object.assign({}, kontext || {});
    for (let i = 0; i < kroky.length; i++) {
      const k = kroky[i];
      const vstup = dosad(k.vstup, ctx);
      const vystup = await zavolej(k.sluzba, vstup, { system: k.system });
      ctx[k.ulozJako || ("krok" + i)] = vystup;
      if (poKroku) poKroku(i, k, vystup);
    }
    return ctx;
  }

  return { SLUZBY, config, nastav, maKlic, lzeVolat, jeTauri, zavolej, spustWorkflow, provideriPro: typ => SLUZBY[typ] ? SLUZBY[typ].provideri : {} };
})();

if (typeof module !== "undefined") module.exports = GenesisAI;

# Genesis Constitution Specification v0.1

*Formát „ústavy" — deklarativního popisu světa, který interpretuje jádro `core.js`.*

**Deskriptivní, ne preskriptivní.** Tento dokument popisuje formát tak, jak ho dnes reálně používají dvě hry (`rules.json` = Project CODEX, `zivot-rules.json` = Ekosystém). Rozšiřuje se, až ho k tomu donutí třetí hra — ne dopředu.

Ústava je jeden JSON objekt. Dělí se na **jádrovou část** (interpretuje `core.js`, univerzální) a **herní část** (čte si konkrétní hra, libovolně rozšiřitelná).

---

## 0. Hlavička

```json
{ "schema_verze": 2, "nazev_hry": "Project CODEX", "_pozn": "volitelný komentář" }
```

- `schema_verze` (číslo) — verze formátu. Runtime odmítne vyšší, než umí. Stará ústava musí běžet dál.
- `nazev_hry`, `_pozn` — volitelné, informativní.

---

## ČÁST A — Jádrová ústava (interpretuje `core.js`)

### A.1 `materialy` (povinné)

Mapa `klíč → definice`. Klíč je strojové jméno (bez diakritiky), používá se v zákonech a generátoru.

```json
"voda": { "nazev": "Voda", "barva": "#3a6ea5", "vlastnosti": ["kapalne", "vodive"], "palivo": 0 }
```

| Pole | Typ | Význam | Čte |
|---|---|---|---|
| `nazev` | string | lidský název | hra (zobrazení, log) |
| `barva` | `#rrggbb` | barva pro renderery | renderer |
| `vlastnosti` | string[] | **tagy**, na kterých stojí zákony (`horlave`, `vodive`, `schudne`, `kapalne`, `pevne`, `organicke`, `drevene`, `kovove`…). Volná sada — nová vlastnost = jen nový řetězec. | jádro (`hasProp`) |
| `palivo` | číslo | výchozí hodnota `vars.palivo` nové buňky | jádro |
| *(doménová)* | — | libovolná další pole si čte hra: `sber`, `spanek`, `tezi`, `potrebaNastroj`, `svit`… | hra |

**Buňka světa** za běhu: `{ mat, stavy:Set, vars:{}, _u:idUdálosti }`. `vars` jsou číselné proměnné (`palivo`, `vlhkost`, `naboj`…), vznikají líně (chybějící = 0).

### A.2 `zakony` (povinné)

Pole pravidel. Každý tik jádro projde zákony v pořadí a aplikuje je na buňky v aktivní oblasti.

```json
{
  "id": "ohen-se-siri",
  "popis": "Oheň přeskakuje na sousední hořlavé a suché věci.",
  "svet": { "prsi": false },
  "kdyz": { "stav": "horici", "neStav": ["zkroceny"] },
  "cil": "soused",
  "pokud": { "vlastnost": "horlave", "neStav": ["horici", "mokry"] },
  "sance": 0.22,
  "udelej": [ { "pridejStav": "horici", "log": "🔥 Oheň se šíří — chytá {material}." } ]
}
```

| Pole | Význam |
|---|---|
| `id` | jedinečný identifikátor |
| `popis` | lidské vysvětlení (i pro kauzální řetěz) |
| `svet` | *(volitelné)* podmínka globálního stavu — zákon platí, jen když `svet[k] === hodnota` (např. `prsi`, `noc`) |
| `kdyz` | podmínka na **spouštěcí** buňku (viz A.3) |
| `cil` | `"sam"` (efekt na spouštěcí buňku) nebo `"soused"` (na 4 ortogonální sousedy) |
| `pokud` | *(jen u `cil:"soused"`)* podmínka na cílového souseda |
| `sance` | *(volitelné)* 0–1; pravděpodobnost aplikace na buňku/souseda (deterministická, seedovaná) |
| `udelej` | pole efektů (viz A.4) |

### A.3 Podmínky (`kdyz`, `pokud`)

Všechna uvedená kritéria musí platit (AND). Chybějící podmínka = vždy pravda.

| Klíč | Význam |
|---|---|
| `material` | materiál je (string) nebo je jedním z (string[]) |
| `vlastnost` / `neVlastnost` | buňka má / nemá vlastnost (string nebo string[]) |
| `stav` / `neStav` | buňka má / nemá stav |
| `var` | číselný test: `{ "vlhkost": { ">=": 2 } }`. Operátory: `>=`, `<=`, `>`, `<`, `=` |
| `aspon_jedno` | pole podmínek — platí, když aspoň jedna z nich platí (OR) |

### A.4 Efekty (`udelej[]`)

Provádějí se v pořadí na cílové buňce.

| Efekt | Význam |
|---|---|
| `pridejStav` / `odeberStav` | přidá/odebere stav (string) |
| `zmenVar` | `{ "vlhkost": 1 }` přičte; `strop`/`dno` v témže efektu omezí (`"strop": {"vlhkost":6}`) |
| `nastavVar` | `{ "naboj": 4 }` nastaví na hodnotu |
| `promenNa` | změní materiál buňky (vyčistí stavy, nastaví výchozí `palivo`) |
| `log` | zpráva do kroniky; `{material}` se nahradí názvem materiálu |

**Kauzalita:** proměna materiálu se vždy, a přidání/odebrání stavu s `log`, zapíše do historie s odkazem na příčinu (událost spouštěcí buňky). Vzniká řetěz „proč".

### A.5 Runtime sémantika (garance jádra)

- **Determinismus.** Veškerá náhoda (`sance`, generátor) běží ze seedovaného proudu. Stejný `seed` + stejné vstupy → identický svět. `Math.random` se v jádru nepoužívá.
- **Pořadí.** Zákony v pořadí pole; buňky v pořadí `y`, pak `x`; sousedé sever/jih/západ/východ.
- **Aktivní oblast.** Zákony běží jen v okně kolem pozorovatele (nekonečný svět). Vzdálené oblasti „spí".
- **Generátor světa** je injektovaná funkce `(x,y) → materiál`; není součástí ústavy (je to kód hry). Ústava popisuje *zákony*, ne *tvar mapy*.

---

## ČÁST B — Herní ústava (čte si konkrétní hra)

Jádro tyto sekce **ignoruje**. Interpretuje je herní vrstva (`sim.js` u CODEXu, `zivot.html` u Ekosystému). Formát je konvence dané hry, ne garance runtime. Přehled dnešního použití:

| Sekce | Hra | Obsah (příklad) |
|---|---|---|
| `bytosti` / `tvorove` | obě | druh → `{ emoji, hp, hustota/start, lovi[], plachy, korist{}, ochocitelny, role, biom[], boss, doupe }` |
| `potreby` | CODEX | `hlad/zizen/energie` → `{ klesa, prah, postih }` |
| `jidlo` | CODEX | `{ hlad, riziko, pece_na }` |
| `predmety` | CODEX | inventářní věci, `{ ikona, nastroj, nosi, efekt{} }` |
| `recepty` | CODEX | výroba, `{ potreba{}, uOhniste }` |
| `stavby` / `budovy` | CODEX | `{ klavesa, material, cena, surovina, vzor[], legenda{} }` |
| `povolani`, `dovednosti`, `questy` | CODEX | RPG vrstva |
| `moduly` | obě | deklarace použitých subsystémů (info) |

**Zásada:** jádro nikdy nepředpokládá herní sekce. Nová hra klidně žádnou z nich nemá (Ekosystém nemá hrdinu, questy ani inventář) — potřebuje jen `materialy` + `zakony` (+ vlastní `tvorove`).

---

## Rozšiřování (verzování)

- Nové **volitelné** pole → `schema_verze` beze změny (staré ústavy fungují).
- Nové **povinné** pole nebo změna sémantiky → zvýšit `schema_verze`; runtime nabídne migraci nebo odmítne.
- Herní sekce nejsou verzované jádrem — spravuje si je hra.

---

*Odvozeno z `rules.json` (CODEX) a `zivot-rules.json` (Ekosystém), 2026-07-16. Strojová validace: `validate.mjs`.*

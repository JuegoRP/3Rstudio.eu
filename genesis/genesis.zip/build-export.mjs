// GENESIS export z příkazové řádky:  node build-export.mjs [index3d.html] [výstup.html]
// Zabalí renderer + engine + aktuální ústavu do JEDNOHO HTML souboru,
// který funguje offline (i z file://) a dá se poslat komukoli.
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const KOREN = path.dirname(fileURLToPath(import.meta.url));
const zdroj = process.argv[2] || "index3d.html";
const cil = process.argv[3] || "Genesis-hra.html";

const html = fs.readFileSync(path.join(KOREN, zdroj), "utf8");
const jadro = fs.readFileSync(path.join(KOREN, "core.js"), "utf8");   // ← jádro musí být v exportu
const sim = fs.readFileSync(path.join(KOREN, "sim.js"), "utf8");
const ustava = fs.readFileSync(path.join(KOREN, "rules.json"), "utf8");
const three = fs.existsSync(path.join(KOREN, "three.min.js")) ? fs.readFileSync(path.join(KOREN, "three.min.js"), "utf8") : "";

const embed = "<script>window.GENESIS_EMBED = " + JSON.stringify(ustava) + ";<\/script>\n";
let out = html;
if (three) out = out.replace('<script src="three.min.js"></script>', () => "<script>" + three + "<\/script>");
out = out.replace('<script src="core.js"></script>', () => "<script>" + jadro + "<\/script>");
out = out.replace('<script src="sim.js"></script>', () => embed + "<script>" + sim + "<\/script>");
out = out.replace(/<span class="nav">[\s\S]*?<\/span>/, "");

fs.writeFileSync(path.isAbsolute(cil) ? cil : path.join(KOREN, cil), out);
const kb = Math.round(Buffer.byteLength(out) / 1024);
console.log("Hotovo → " + cil + " (" + kb + " kB, jeden soubor, offline). Pošli ho komukoli.");

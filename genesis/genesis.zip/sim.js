"use strict";
// ============================================================
// GENESIS — sdílené jádro simulace (Genesis Core).
// Čte ústavu z rules.json a vykonává ji. O zobrazení nic neví.
// Svět je nekonečný: generuje se po chuncích tam, kam jde hrdina.
// Zákony tikají pomalu a jen v okolí hrdiny; pohyb je spojitý.
// RPG vrstva (questy, dovednosti, povolání, boss) = data v ústavě.
// ============================================================

// Project CODEX = HRA nad sdíleným jádrem GenesisCore (core.js). Generické věci
// (svět, chunky, RNG, interpret zákonů) deleguje na jádro; herní vrstva (hrdina,
// bytosti, biomy, questy…) zůstává tady. Tentýž core.js pohání i Ekosystém.
const CHUNK = GenesisCore.CHUNK;
let SEED = 20260710;

let MATERIALY = {}, ZAKONY = [], BYTOSTI_DEF = {}, POVOLANI_DEF = {}, DOVEDNOSTI_DEF = [], QUESTY_DEF = [];
let POTREBY_DEF = {}, JIDLO_DEF = {}, PREDMETY_DEF = {}, RECEPTY_DEF = {}, BUDOVY_DEF = [];
const chunky = GenesisCore.chunks();   // tatáž Mapa jako v jádru
let bytosti = [];
const svet = GenesisCore.world;        // globální stav světa žije v jádru
let tik = 0, pauza = false, nastroj = "prozkoumat";
let poslednePusobil = {}, posledniLog = {}, textPravidel = "";
let bleskCas = -999;
let HOOKS = {};

// směr "dopředu/doprava" pro pohyb hrdiny — přepisuje ho renderer podle kamery
let smerVpred = { x: 0, y: -1 }, smerVpravo = { x: 1, y: 0 };

// moduly, stavby, projektily, denní cyklus
let STAVBY_DEF = [], MODULY_DEF = [];
const ZNAME_MODULY = ["svet-grid", "pocasi", "denni-cyklus", "boj-zblizka", "projektily", "stavba", "tezba", "vyroba"];
let strely = [];
const DEN_TIKU = 1400;

// rod = linie rekrutů: XP, úroveň a dovednosti přežívají smrt (zápisky po padlých)
let rod = { xp: 0, uroven: 1, body: 0, dovednosti: [] };
let questStav = {};              // id -> {pocet, hotovo}
let hrdina = null, cisloRekruta = 0, pamatnik = [];
let zvolenePovolani = null;

// ---------- ústava: načtení a živé přenačítání ----------
async function nactiPravidla(prvni) {
  try {
    // exportovaná single-file hra nese ústavu v sobě (window.GENESIS_EMBED) → jede i z file://
    const text = (typeof window !== "undefined" && window.GENESIS_EMBED)
      ? window.GENESIS_EMBED
      : await (await fetch("rules.json?t=" + Date.now())).text();
    if (text !== textPravidel) {
      const data = JSON.parse(text);
      GenesisCore.loadRules(data);        // materiály + zákony do jádra
      MATERIALY = data.materialy;
      ZAKONY = data.zakony;
      BYTOSTI_DEF = data.bytosti || {};
      DOUPATA = [];
      for (const typ in BYTOSTI_DEF) if (BYTOSTI_DEF[typ].doupe) DOUPATA.push(BYTOSTI_DEF[typ].doupe);
      POVOLANI_DEF = data.povolani || {};
      DOVEDNOSTI_DEF = data.dovednosti || [];
      QUESTY_DEF = data.questy || [];
      POTREBY_DEF = data.potreby || {};
      JIDLO_DEF = data.jidlo || {};
      PREDMETY_DEF = data.predmety || {};
      RECEPTY_DEF = data.recepty || {};
      STAVBY_DEF = data.stavby || [];
      BUDOVY_DEF = data.budovy || [];
      MODULY_DEF = data.moduly || [];
      for (const m of MODULY_DEF) if (ZNAME_MODULY.indexOf(m) === -1)
        zapis("🧩 Modul <b>" + m + "</b> zatím není nainstalován — pravidla, která na něm stojí, počkají.");
      if (!zvolenePovolani || !POVOLANI_DEF[zvolenePovolani]) zvolenePovolani = Object.keys(POVOLANI_DEF)[0] || null;
      vykresliUstavu();
      vykresliPovolani();
      vykresliQuesty();
      vykresliDovednosti();
      if (HOOKS.poPravidlech) HOOKS.poPravidlech();
      if (!prvni && textPravidel) zapis("📜 <b>Ústava světa se změnila — nová pravidla platí okamžitě.</b>");
      textPravidel = text;
    }
  } catch (e) {
    if (prvni) {
      const el = document.getElementById("chyba");
      el.style.display = "flex";
      el.innerHTML = "Nemůžu načíst <b>rules.json</b> — otevři stránku přes lokální server:<br><code>cd Genesis && python3 -m http.server 8642</code><br>a pak <b>http://localhost:8642</b>";
      throw e;
    }
  }
  setTimeout(() => nactiPravidla(false), 1000);
}

// ---------- RNG & šum: deleguje na jádro (stejné API) ----------
function hash(x, y, s) { return GenesisCore.hash(x, y, s); }
function sum2(x, y, meritko, s) { return GenesisCore.noise(x, y, meritko, s); }

// ---------- geografie jako na Zemi: kontinenty, oceány, teplota, vlhkost ----------
// pevninská hladina (0..1): velké měřítko = kontinenty a oceány; <0.4 je moře
function pevnina(x, y) {
  return sum2(x, y, 420, 1) * 0.6 + sum2(x, y, 160, 5) * 0.3 + sum2(x, y, 55, 12) * 0.1;
}
// horský hřbet (0..1) — ridged noise dává protáhlá pohoří
function hory(x, y) { return 1 - Math.abs(sum2(x, y, 240, 3) - 0.5) * 2; }
// teplota podle zeměpisné "šířky" (pásy) + trocha šumu; 0 pól, 1 rovník
function teplota(x, y) { return 0.5 + 0.5 * Math.sin(y / 900) + (sum2(x, y, 300, 7) - 0.5) * 0.5; }
function vlhkost(x, y) { return sum2(x, y, 200, 2); }
// řeka: údolní síť. Míra „řekovitosti" 0..1 — u hřebene ridged noise; roste směrem k moři.
function rekaMira(x, y) {
  const r = 1 - Math.abs(sum2(x, y, 150, 9) - 0.5) * 2;     // páteř řeky (klikatá linie)
  if (r < 0.975) return 0;
  const p = pevnina(x, y);
  const kMori = Math.max(0, Math.min(1, (0.62 - p) / 0.22)); // blíž k moři → širší koryto
  return (r - 0.975) / 0.025 * (0.4 + 0.6 * kMori);
}

const HLADINA_MORE = 0.4;
let DOUPATA = [];
function vyskaTerenu(x, y) {
  const p = pevnina(x, y);
  let e;
  if (p < HLADINA_MORE) e = (p - HLADINA_MORE) * 26;                    // moře: hlubší dál od břehu
  else {
    const nad = (p - HLADINA_MORE) / (1 - HLADINA_MORE);                // 0 u břehu … 1 vnitrozemí
    // členitější pevnina: tři oktávy detailu místo jedné
    e = nad * 4 + (sum2(x, y, 60, 20) - 0.5) * 3 + (sum2(x, y, 22, 12) - 0.5) * 1.8 + (sum2(x, y, 9, 21) - 0.5) * 0.8;
    const h = hory(x, y);
    if (h > 0.5) {                                                      // VYŠŠÍ a ostřejší hory
      const horske = (h - 0.5) / 0.5;                                   // 0..1
      e += horske * horske * 60 * (0.4 + 0.6 * nad) + (sum2(x, y, 14, 30) - 0.5) * 6 * horske; // skalnaté štíty
    }
    // řeka se zařezává tím hloub, čím širší koryto (pramen mělký v horách → hluboké u moře)
    const rm = rekaMira(x, y);
    if (rm > 0) e = Math.min(e, e * (1 - rm) - rm * (1.2 + 2.5 * (1 - Math.min(1, e / 8))));
  }
  const dDomov = Math.hypot(x - 16, y - 16);
  if (dDomov < 26) e = e * Math.min(1, Math.max(0, (dDomov - 12) / 14)) + 0.3 * Math.max(0, 1 - dDomov / 26);
  for (const [dx, dy] of DOUPATA) {
    const d = Math.hypot(x - dx, y - dy);
    if (d < 18) e *= Math.min(1, Math.max(0.1, (d - 9) / 9));
  }
  return Math.max(e, -8);
}
function reka(x, y) { return rekaMira(x, y) > 0.35; }

function teren(x, y) {
  if (Math.hypot(x - 16, y - 16) < 16) return hash(x, y, 9) < 0.06 ? "hlina" : "trava"; // domovská louka
  const v = vyskaTerenu(x, y);
  if (v < -0.1) return "voda";                       // moře / jezera / řeky
  if (reka(x, y) && v < 1.2) return "voda";
  const t = teplota(x, y), vlh = vlhkost(x, y);
  // vrcholky hor: sníh / holá skála (v nich rudy)
  if (v > 7) return "snih";
  if (v > 4.5) {
    if (hash(x, y, 20) < 0.12) return "ruda_zelezna";
    if (hash(x, y, 21) < 0.09) return "uhli";
    return t < 0.3 ? "snih" : "kamen";
  }
  // pobřeží = pláž
  if (v < 0.35) return t < 0.25 ? "snih" : "pisek";
  // biom podle teploty a vlhkosti
  if (t < 0.28) return hash(x, y, 30) < 0.12 ? "strom" : "snih";                    // tundra
  if (t > 0.72 && vlh < 0.4) {                                                       // poušť
    if (hash(x, y, 31) < 0.02) return "kaktus";
    return "pisek";
  }
  if (t > 0.6 && vlh > 0.6) {                                                        // prales
    if (hash(x, y, 32) < 0.45) return "dzungle";
    if (hash(x, y, 33) < 0.08) return "kere";
    return "trava";
  }
  if (t > 0.5 && vlh < 0.45) {                                                       // savana
    if (hash(x, y, 34) < 0.04) return "strom";
    return "savana";
  }
  // mírné pásmo: les a louky
  if (vlh > 0.5 && hash(x, y, 5) < 0.5) return "strom";
  if (vlh > 0.45 && hash(x, y, 8) < 0.05) return "kere";
  if (hash(x, y, 6) < 0.04) return "hlina";
  if (hash(x, y, 7) < 0.01) return "strom";
  return "trava";
}

// buňky/svět řídí jádro; na každou novou buňku doplníme herní proměnné CODEXu
GenesisCore.setCellInit(b => { b.vars.vlhkost = 0; b.vars.naboj = 0; b.vars.hniloba = 0; b.vars.klid = 0; });
function novaBunka(mat) { return GenesisCore.novaBunka(mat); }
function bunka(x, y) { return GenesisCore.cell(x, y); }

// razítka staveb/vesnic/doupat + osídlení běží po vygenerování chunku (hook jádra)
GenesisCore.on("chunk", c => {
  razitka(c);
  if (jeVesnice(c.cx, c.cy) && !(c.cx === 0 && c.cy === 0)) postavVesnici(c);
  osidleni(c);
  udalost("objeven_chunk");
});

function poloz(x, y, mat) { GenesisCore.place(x, y, mat); }

// pevné stavby otisknuté do světa (jen uvnitř právě generovaného chunku)
function razitka(c) {
  const doChunku = (x, y, mat) => {
    const lx = x - c.cx * CHUNK, ly = y - c.cy * CHUNK;
    if (lx >= 0 && lx < CHUNK && ly >= 0 && ly < CHUNK) c.bunky[ly * CHUNK + lx] = novaBunka(mat);
  };
  // vesnice na domovské louce
  for (const [px, py] of [[8, 6], [22, 9]])
    for (let y = py; y < py + 5; y++) for (let x = px; x < px + 7; x++)
      if (y === py || y === py + 4 || x === px || x === px + 6) doChunku(x, y, "drevo");
  for (let y = 18; y <= 24; y++) for (let x = 24; x <= 30; x++)
    if (Math.hypot(x - 27, y - 21) < 3) doChunku(x, y, "voda");
  // doupata bossů podle ústavy (bytost s polem "doupe")
  for (const typ in BYTOSTI_DEF) {
    const def = BYTOSTI_DEF[typ];
    if (!def.doupe) continue;
    const [dx, dy] = def.doupe;
    const lcx = Math.floor(dx / CHUNK), lcy = Math.floor(dy / CHUNK);
    if (lcx !== c.cx || lcy !== c.cy) continue;
    for (let y = dy - 8; y <= dy + 8; y++) for (let x = dx - 8; x <= dx + 8; x++) {
      const d = Math.hypot(x - dx, y - dy);
      if (d >= 5.5 && d < 7.5) doChunku(x, y, "kamen");
      else if (d < 5.5) doChunku(x, y, "popel");
    }
    doChunku(dx - 6, dy, "hlina"); doChunku(dx + 6, dy, "hlina"); // brány
    bytosti.push(novaBytost(typ, def, dx, dy));
    zapis("🗿 Kdesi v dálce se cosi pohnulo… (" + typ + " se probudil)");
  }
}

function novaBytost(typ, def, x, y) {
  return {
    typ: typ, emoji: def.emoji || "❓", x: x, y: y,
    hp: def.hp || 1, umiVodu: !!def.umiVodu, plachy: !!def.plachy,
    lovi: def.lovi || null, dosah: def.dosah || 10, sytost: def.sytost !== undefined ? def.sytost : 80,
    sila: def.sila || 1, xpZa: def.xp || 0, boss: !!def.boss,
    role: def.role || null, mirumilovny: !!def.mirumilovny, obchod: def.obchod || null, domov: { x: x, y: y },
    stun: 0, zivy: true, rozklad: 0, cd: -999, najedl: -999
  };
}

function osidleni(c) {
  for (const typ in BYTOSTI_DEF) {
    const def = BYTOSTI_DEF[typ];
    if (!def.hustota) continue;
    let n = Math.floor(def.hustota);
    if (hash(c.cx, c.cy, 100 + n) < def.hustota - n) n++;
    for (let i = 0; i < n; i++) {
      for (let p = 0; p < 12; p++) {
        const lx = Math.floor(hash(c.cx * 7 + i, c.cy * 13 + p, 200) * CHUNK);
        const ly = Math.floor(hash(c.cx * 11 + i, c.cy * 17 + p, 300) * CHUNK);
        const b = c.bunky[ly * CHUNK + lx];
        // zvíře patří do svého biomu (materiál buňky), pokud je určen
        if (maVlastnost(b, "schudne") && (!def.biom || def.biom.indexOf(b.mat) !== -1)) {
          bytosti.push(novaBytost(typ, def, c.cx * CHUNK + lx, c.cy * CHUNK + ly));
          break;
        }
      }
    }
  }
}

// vesnice: shluk chalup + obyvatelé (NPC s rolí). Rozmístěné procedurálně po světě.
function jeVesnice(cx, cy) { return hash(cx, cy, 500) < 0.06; }   // ~6 % chunků má vesnici
function postavVesnici(c) {
  const stred = c.cx * CHUNK + 8 + Math.floor(hash(c.cx, c.cy, 501) * 14);
  const stredY = c.cy * CHUNK + 8 + Math.floor(hash(c.cx, c.cy, 502) * 14);
  const doChunku = (x, y, mat) => { const lx = x - c.cx * CHUNK, ly = y - c.cy * CHUNK; if (lx >= 0 && lx < CHUNK && ly >= 0 && ly < CHUNK && maVlastnost(c.bunky[ly*CHUNK+lx], "schudne")) c.bunky[ly * CHUNK + lx] = novaBunka(mat); };
  // 3–4 chalupy
  for (let ch = 0; ch < 4; ch++) {
    const px = stred + Math.floor((hash(c.cx + ch, c.cy, 510) - 0.5) * 18);
    const py = stredY + Math.floor((hash(c.cx, c.cy + ch, 511) - 0.5) * 18);
    for (let y = py; y < py + 4; y++) for (let x = px; x < px + 5; x++)
      if (y === py || y === py + 3 || x === px || x === px + 4) doChunku(x, y, "drevo");
  }
  doChunku(stred, stredY, "ohniste");
  // obyvatelé: obchodník, strážný, pár vesničanů
  const spawnNPC = (typ, ox, oy) => { const d = BYTOSTI_DEF[typ]; if (d) bytosti.push(novaBytost(typ, d, stred + ox, stredY + oy)); };
  spawnNPC("Obchodník", 1, 0);
  spawnNPC("Strážný", -2, 1);
  spawnNPC("Vesničan", 2, 2);
  spawnNPC("Vesničan", -1, -2);
}

function jeSchudna(x, y) { return maVlastnost(bunka(x, y), "schudne"); }

function aktivniRozsah() {
  const h = hrdina ? hrdinaBunka() : { x: 16, y: 16 };
  const cx = Math.floor(h.x / CHUNK), cy = Math.floor(h.y / CHUNK);
  return { x0: (cx - 1) * CHUNK, y0: (cy - 1) * CHUNK, x1: (cx + 2) * CHUNK, y1: (cy + 2) * CHUNK };
}

function generujSvet() {
  GenesisCore.config({ seed: SEED });
  GenesisCore.reset();      // vyprázdní chunky i tik v jádru
  bytosti = [];
  questStav = {};
  spawnHrdinu();
  tik = 0;
  vykresliQuesty();
}

// ---------- rod, povolání, dovednosti, questy ----------
// vybavení: z předmětů typu "nosi" (telo/ruka) nosí hrdina nejlepší, který má
function vybaveni() {
  const nes = { telo: null, ruka: null };
  if (!hrdina) return nes;
  for (const k in hrdina.inventar) {
    if (!(hrdina.inventar[k] > 0)) continue;
    const p = PREDMETY_DEF[k];
    if (!p || !p.nosi) continue;
    const sila = (p.efekt && (p.efekt.obrana || p.efekt.sila)) || 0;
    if (!nes[p.nosi] || sila > nes[p.nosi].sila) nes[p.nosi] = { klic: k, def: p, sila: sila };
  }
  return nes;
}

function efektySoucet() {
  const vysledek = { drevoNavic: 0, rychlost: 1, sila: 0, strelba: 0, obrana: 0, plavani: false, ohnivzdornost: 0 };
  const zapocti = ef => {
    if (!ef) return;
    if (ef.drevoNavic) vysledek.drevoNavic += ef.drevoNavic;
    if (ef.rychlost) vysledek.rychlost *= ef.rychlost;
    if (ef.sila) vysledek.sila += ef.sila;
    if (ef.strelba) vysledek.strelba += ef.strelba;
    if (ef.obrana) vysledek.obrana += ef.obrana;
    if (ef.plavani) vysledek.plavani = true;
    if (ef.ohnivzdornost) vysledek.ohnivzdornost = Math.max(vysledek.ohnivzdornost, ef.ohnivzdornost);
  };
  const pov = POVOLANI_DEF[hrdina ? hrdina.povolani : zvolenePovolani];
  if (pov) zapocti(pov.efekt);
  for (const id of rod.dovednosti) {
    const d = DOVEDNOSTI_DEF.find(x => x.id === id);
    if (d) zapocti(d.efekt);
  }
  const v = vybaveni();
  if (v.telo) zapocti(v.telo.def.efekt);
  if (v.ruka) zapocti(v.ruka.def.efekt);
  return vysledek;
}

function silaHrdiny() {
  const pov = POVOLANI_DEF[hrdina.povolani] || {};
  return (pov.sila || 1) + efektySoucet().sila;
}

function pridejXp(n) {
  if (!n) return;
  rod.xp += n;
  while (rod.xp >= 60 * rod.uroven) {
    rod.xp -= 60 * rod.uroven;
    rod.uroven++;
    rod.body++;
    zapis("🌟 <b>Úroveň " + rod.uroven + "!</b> Rod získal 1 bod dovedností.");
  }
  aktualizujHud();
  vykresliDovednosti();
}

function kupDovednost(id) {
  const d = DOVEDNOSTI_DEF.find(x => x.id === id);
  if (!d || rod.dovednosti.indexOf(id) !== -1) return;
  if (rod.body < d.cena) { zapis("🚫 Nedostatek bodů na dovednost " + d.nazev + "."); return; }
  for (const req of (d.vyzaduje || [])) if (rod.dovednosti.indexOf(req) === -1) { zapis("🚫 " + d.nazev + " vyžaduje jinou dovednost."); return; }
  rod.body -= d.cena;
  rod.dovednosti.push(id);
  zapis("📖 Rod se naučil: <b>" + d.nazev + "</b> — " + d.popis);
  aktualizujHud();
  vykresliDovednosti();
}

function udalost(nazev) {
  for (const q of QUESTY_DEF) {
    if (q.udalost !== nazev) continue;
    let s = questStav[q.id];
    if (!s) s = questStav[q.id] = { pocet: 0, hotovo: false };
    if (s.hotovo) continue;
    s.pocet++;
    if (s.pocet >= q.pocet) {
      s.hotovo = true;
      zapis("✅ <b>ÚKOL SPLNĚN: " + q.nazev + "</b>" + (q.odmena && q.odmena.xp ? " (+" + q.odmena.xp + " xp)" : ""));
      if (q.odmena && q.odmena.xp) pridejXp(q.odmena.xp);
    }
    vykresliQuesty();
  }
}

function spawnHrdinu() {
  cisloRekruta++;
  let sx = 16, sy = 16;
  for (let r = 0; r < 20 && !jeSchudna(sx, sy); r++) { sx += 1; sy += (r % 2); }
  const povolani = zvolenePovolani || Object.keys(POVOLANI_DEF)[0] || "Poutník";
  const pov = POVOLANI_DEF[povolani] || { hp: 5 };
  hrdina = { x: sx + 0.5, y: sy + 0.5, hp: pov.hp || 5, maxHp: pov.hp || 5, povolani: povolani,
             stun: 0, drevo: 0, mokry: false, zivy: true,
             smerX: 0, smerY: -1, vyskaSkoku: 0, rychlostSkoku: 0, utok: 0, strelCd: -999,
             potreby: {}, inventar: { kamen: 5 }, spanek: 0,
             jmeno: povolani + " – Rekrut #" + cisloRekruta, posledniZvuk: -999 };
  for (const p in POTREBY_DEF) hrdina.potreby[p] = 100;
  aktualizujHud();
}

function hrdinaBunka() { return { x: Math.floor(hrdina.x), y: Math.floor(hrdina.y) }; }

// start z menu: zvol povolání a začni od Rekruta #1
function zacniHru(povolani) {
  if (povolani && POVOLANI_DEF[povolani]) zvolenePovolani = povolani;
  cisloRekruta = 0;
  spawnHrdinu();
  vykresliPovolani();
}

// uložení/načtení postupu (seed + rod + questy + pozice). Ruční změny terénu se neukládají.
function ulozHru() {
  try {
    const data = { seed: SEED, rod: rod, questStav: questStav, pamatnik: pamatnik, cisloRekruta: cisloRekruta,
      povolani: hrdina ? hrdina.povolani : zvolenePovolani,
      x: hrdina ? hrdina.x : 16, y: hrdina ? hrdina.y : 16, hp: hrdina ? hrdina.hp : 5, drevo: hrdina ? hrdina.drevo : 0,
      potreby: hrdina ? hrdina.potreby : null, inventar: hrdina ? hrdina.inventar : null,
      prsi: !!svet.prsi, rng: GenesisCore.rngSnapshot(), tikSveta: GenesisCore.tik, verze: 2 };
    localStorage.setItem("genesis_save", JSON.stringify(data));
    zapis("💾 <b>Uloženo.</b> (svět, rod, úkoly)");
    return true;
  } catch (e) { zapis("🚫 Uložení selhalo: " + e.message); return false; }
}

function ulozHruTiche() {
  const data = { seed: SEED, rod: rod, questStav: questStav, pamatnik: pamatnik, cisloRekruta: cisloRekruta,
    povolani: hrdina ? hrdina.povolani : zvolenePovolani,
    x: hrdina ? hrdina.x : 16, y: hrdina ? hrdina.y : 16, hp: hrdina ? hrdina.hp : 5, drevo: hrdina ? hrdina.drevo : 0,
    potreby: hrdina ? hrdina.potreby : null, inventar: hrdina ? hrdina.inventar : null,
    prsi: !!svet.prsi, rng: GenesisCore.rngSnapshot(), tikSveta: GenesisCore.tik, verze: 2 };
  localStorage.setItem("genesis_save", JSON.stringify(data));
}

function jeUlozeno() { try { return !!localStorage.getItem("genesis_save"); } catch { return false; } }

function nactiHru() {
  let data;
  try { data = JSON.parse(localStorage.getItem("genesis_save")); } catch { return false; }
  if (!data) return false;
  SEED = data.seed;
  rod = data.rod || rod;
  questStav = data.questStav || {};
  pamatnik = data.pamatnik || [];
  cisloRekruta = (data.cisloRekruta || 1) - 1;
  zvolenePovolani = data.povolani || zvolenePovolani;
  GenesisCore.config({ seed: SEED });
  GenesisCore.reset();
  bytosti = [];
  spawnHrdinu();
  if (data.x !== undefined) { hrdina.x = data.x; hrdina.y = data.y; hrdina.hp = data.hp; hrdina.drevo = data.drevo || 0; }
  if (data.potreby) hrdina.potreby = data.potreby;
  if (data.inventar) hrdina.inventar = data.inventar;
  if (data.rng !== undefined) GenesisCore.rngRestore(data.rng);   // obnov proud náhody (determinismus)
  svet.prsi = !!data.prsi;
  tik = 0;
  vykresliQuesty(); vykresliDovednosti(); vykresliPovolani(); aktualizujHud();
  zapis("📂 <b>Hra načtena.</b> Rod na úrovni " + rod.uroven + ", padlých: " + pamatnik.length + ".");
  if (HOOKS.poDesti) HOOKS.poDesti();
  if (HOOKS.poTiku) HOOKS.poTiku();
  return true;
}

// ---------- interpret zákonů: deleguje na jádro (log jde přes hook) ----------
function maVlastnost(b, v) { return GenesisCore.hasProp(b, v); }
function splnuje(b, pod) { return GenesisCore.splnuje(b, pod); }
function proved(b, efekty, zakon) { return GenesisCore.proved(b, efekty, zakon); }
function sousedi(x, y) { return GenesisCore.neighbors(x, y); }
GenesisCore.on("log", d => { if (d.zakon) { poslednePusobil[d.zakon.id] = GenesisCore.tik; zapisZakona(d.zakon, d.text); } else zapis(d.text); });

function krokSimulace() {
  // denní cyklus musí být nastaven PŘED zákony (čtou svet.noc)
  const tNext = GenesisCore.tik + 1;
  svet.cas = (tNext % DEN_TIKU) / DEN_TIKU;
  const denniObloha = svet.cas < 0.78 ? Math.sin(svet.cas / 0.78 * Math.PI) : 0;
  svet.svetlost = 0.22 + 0.78 * denniObloha;   // spodní mez ať se v noci pořád dá dohlédnout
  const noc = denniObloha < 0.05;
  if (noc !== !!svet.noc) {
    svet.noc = noc;
    zapis(noc ? "🌙 <b>Padla noc.</b> Vlci teď loví bez ohledu na hlad…" : "🌅 <b>Svítá.</b>");
  }
  const akt = aktivniRozsah();
  GenesisCore.step(akt);      // interpret zákonů běží v jádru (nad GenesisCore.world = svet)
  tik = GenesisCore.tik;
  // bouřka: za deště občas udeří blesk z nebe (jen v živé oblasti)
  if (svet.prsi && GenesisCore.rand() < 0.02) {
    const x = akt.x0 + Math.floor(GenesisCore.rand() * (akt.x1 - akt.x0));
    const y = akt.y0 + Math.floor(GenesisCore.rand() * (akt.y1 - akt.y0));
    const b = bunka(x, y);
    b.stavy.add("nabity");
    b.vars.naboj = 5;
    b._u = GenesisCore.udalost("⛈️ blesk z bouřky", x, y, []);   // kořen kauzálního řetězu
    bleskCas = tik;
    if (tik - (posledniLog._bourka || -999) > 15) {
      posledniLog._bourka = tik;
      zapis("🌩️ <b>Z nebe udeřil blesk</b> — zasáhl materiál " + ((MATERIALY[b.mat] || {}).nazev || b.mat) + ".");
    }
  }
  krokBytosti(akt);
  krokHrdiny();
  if (!casovaniAktivni && GenesisCore.tik % SNAP_INTERVAL === 0) udelejSnimek();   // time-travel snímek
  aktualizujHud();
  if (HOOKS.poTiku) HOOKS.poTiku();
}

// ---------- zvěř (druhy, lov a plachost definuje ústava) ----------
function krokBytosti(akt) {
  for (const b of bytosti) {
    // mimo živou oblast svět spí
    if (b.x < akt.x0 - 4 || b.x >= akt.x1 + 4 || b.y < akt.y0 - 4 || b.y >= akt.y1 + 4) continue;
    if (!b.zivy) {
      b.rozklad++;
      if (b.rozklad === 60) zapis("🦴 Tělo (" + b.typ + ") se rozkládá…");
      if (b.rozklad > 140) { b.pryc = true; zapis("🌱 Z těla (" + b.typ + ") zbyly jen kosti, příroda si ho vzala."); }
      continue;
    }
    const zde = bunka(b.x, b.y);
    if (zde.stavy.has("nabity") && b.stun === 0) {
      b.stun = 8;
      zapis("⚡ <b>" + b.typ + "</b> dostal ránu proudem — svalová křeč, nemůže se hnout!");
    }
    if (b.stun > 0) { b.stun--; continue; }
    if (zde.stavy.has("horici")) {
      b.hp--;
      if (b.hp <= 0) { b.zivy = false; b._u = GenesisCore.udalost("☠️ " + b.typ + " uhořel", b.x, b.y, [zde._u]); zapis("☠️ <b>" + b.typ + "</b> uhořel. Tělo zůstává ve světě."); continue; }
    }
    // NPC s rolí: strážný loví šelmy, ostatní se drží poblíž domova (nepobíhají do dáli)
    if (b.role) {
      if (b.lovi) {   // strážný — brání okolí před šelmami
        let cil = null, nej = b.dosah + 1;
        for (const k of bytosti) { if (k.zivy && !k.role && b.lovi.indexOf(k.typ) !== -1) { const d = Math.abs(k.x - b.x) + Math.abs(k.y - b.y); if (d < nej) { nej = d; cil = k; } } }
        if (cil) {
          if (nej <= 1) { if (tik - b.cd > 8) { b.cd = tik; cil.hp -= b.sila; if (cil.hp <= 0) { cil.zivy = false; zapis("💂 Strážný skolil " + cil.typ + "."); } } }
          else krokSmerem(b, cil.x, cil.y);
          continue;
        }
      }
      if (b.domov && Math.abs(b.x - b.domov.x) + Math.abs(b.y - b.domov.y) > 6) krokSmerem(b, b.domov.x, b.domov.y);
      else if (GenesisCore.rand() < 0.25) { const dx = [-1,0,1][Math.floor(GenesisCore.rand()*3)], dy = [-1,0,1][Math.floor(GenesisCore.rand()*3)]; if (muzeBytost(b, b.x+dx, b.y+dy)) { b.x += dx; b.y += dy; } }
      continue;
    }
    // ochočený spojenec drží u hrdiny a brání ho — loví jeho nepřátele
    if (b.spojenec && hrdina && hrdina.zivy) {
      const h = hrdinaBunka();
      let cil = null, nej = 6;
      for (const p of bytosti) { if (p.zivy && p.lovi && !p.spojenec) { const d = Math.abs(p.x - b.x) + Math.abs(p.y - b.y); if (d < nej) { nej = d; cil = p; } } }
      if (cil) {
        if (nej <= 1) { if (tik - b.cd > 8) { b.cd = tik; cil.hp -= 1; if (cil.hp <= 0) { cil.zivy = false; zapis("💚 " + b.typ + " (spojenec) srazil " + cil.typ + "!"); } } }
        else krokSmerem(b, cil.x, cil.y);
      } else if (Math.abs(b.x - h.x) + Math.abs(b.y - h.y) > 3) krokSmerem(b, h.x, h.y);
      continue;
    }
    if (b.boss && tik % 2 === 1) continue; // bossové jsou těžcí a pomalí
    // dravec: má-li hlad, loví nejbližší kořist ze seznamu v ústavě
    if (b.lovi && (tik - b.najedl > b.sytost || (BYTOSTI_DEF[b.typ] && BYTOSTI_DEF[b.typ].nocni && svet.noc))) {
      let cil = null, nej = b.dosah + 1;
      for (const k of bytosti) {
        if (k === b || !k.zivy || b.lovi.indexOf(k.typ) === -1) continue;
        const d = Math.abs(k.x - b.x) + Math.abs(k.y - b.y);
        if (d < nej) { nej = d; cil = k; }
      }
      if (b.lovi.indexOf("hrdina") !== -1 && hrdina && hrdina.zivy) {
        const h = hrdinaBunka();
        const d = Math.abs(h.x - b.x) + Math.abs(h.y - b.y);
        if (d < nej) { nej = d; cil = "hrdina"; }
      }
      if (cil) {
        if (nej <= 1) {
          if (tik - b.cd > 8) {
            b.cd = tik;
            if (cil === "hrdina") {
              zapis((b.boss ? "🗿" : "🐺") + " <b>" + b.typ + " zasáhl</b> hrdinu!");
              zranHrdinu("dostal ho " + b.typ, b.sila);
            } else {
              cil.hp -= b.sila;
              if (cil.hp <= 0) {
                cil.zivy = false;
                b.najedl = tik;
                zapis("🩸 <b>" + b.typ + " ulovil</b> bytost " + cil.typ + ". Nasytil se.");
              }
            }
          }
          continue;
        }
        const th = cil === "hrdina" ? hrdinaBunka() : cil;
        if (krokSmerem(b, th.x, th.y)) continue;
      }
    }
    // plaché bytosti utíkají před svými lovci
    if (b.plachy) {
      let hrozba = null;
      for (const p of bytosti) {
        if (!p.zivy || !p.lovi || p.lovi.indexOf(b.typ) === -1) continue;
        if (Math.abs(p.x - b.x) + Math.abs(p.y - b.y) <= 4) { hrozba = p; break; }
      }
      if (hrozba) { krokSmerem(b, 2 * b.x - hrozba.x, 2 * b.y - hrozba.y); continue; }
    }
    // útěk před ohněm, jinak toulání
    const ohenBlizko = sousedi(b.x, b.y).some(s => s.stavy.has("horici"));
    if (ohenBlizko || GenesisCore.rand() < 0.45) {
      const moznosti = [];
      for (const [dx, dy] of [[0, -1], [0, 1], [-1, 0], [1, 0]]) {
        if (muzeBytost(b, b.x + dx, b.y + dy)) moznosti.push([b.x + dx, b.y + dy]);
      }
      if (moznosti.length) {
        const [nx, ny] = moznosti[Math.floor(GenesisCore.rand() * moznosti.length)];
        b.x = nx; b.y = ny;
      }
    }
  }
  bytosti = bytosti.filter(b => !b.pryc);
}

function muzeBytost(b, nx, ny) {
  const c = bunka(nx, ny);
  if (c.stavy.has("horici")) return false;
  if (c.mat === "voda") return b.umiVodu;
  return maVlastnost(c, "schudne");
}

function krokSmerem(b, tx, ty) {
  const kroky = [];
  if (tx > b.x) kroky.push([1, 0]); if (tx < b.x) kroky.push([-1, 0]);
  if (ty > b.y) kroky.push([0, 1]); if (ty < b.y) kroky.push([0, -1]);
  for (const [dx, dy] of kroky) {
    if (muzeBytost(b, b.x + dx, b.y + dy)) { b.x += dx; b.y += dy; return true; }
  }
  return false;
}

// ---------- hrdina ----------
function zranHrdinu(pricina, kolik) {
  if (!hrdina.zivy) return;
  // brnění pohltí část rány (vždy ale projde aspoň 1)
  const skutecne = Math.max(1, (kolik || 1) - efektySoucet().obrana);
  hrdina.hp -= skutecne;
  if (hrdina.hp <= 0) {
    hrdina.zivy = false;
    const h = hrdinaBunka();
    zapis("⚰️ <b>" + hrdina.jmeno + "</b> — " + pricina + ". Jméno vytesáno na Památník padlých.");
    pamatnik.push(hrdina.jmeno);
    bytosti.push({ typ: hrdina.jmeno, emoji: "🧑", x: h.x, y: h.y, zivy: false, rozklad: 0, cd: -999, najedl: -999 });
    spawnHrdinu();
    zapis("🌅 Do světa přichází <b>" + hrdina.jmeno + "</b>. Svět se neresetoval — a zkušenost rodu (úroveň " + rod.uroven + ") zůstává.");
  }
  aktualizujHud();
}

function krokHrdiny() {
  if (!hrdina || !hrdina.zivy) return;
  const h = hrdinaBunka();
  const zde = bunka(h.x, h.y);
  if (zde.stavy.has("nabity") && hrdina.stun === 0) {
    hrdina.stun = 8;
    zapis("⚡ <b>" + hrdina.jmeno + "</b> dostal ránu proudem — nemůže se hnout!");
  }
  if (hrdina.stun > 0) hrdina.stun--;
  if (zde.stavy.has("horici")) {
    if (GenesisCore.rand() >= efektySoucet().ohnivzdornost) {
      zapis("🔥 <b>" + hrdina.jmeno + "</b> stojí v ohni!");
      zranHrdinu("uhořel", 1);
    }
  }
  const vlhko = svet.prsi || zde.stavy.has("mokry");
  if (vlhko && !hrdina.mokry) {
    hrdina.mokry = true;
    zapis("💧 " + hrdina.jmeno + " promokl na kost.");
  }
  if (!vlhko && hrdina.mokry && GenesisCore.rand() < 0.05) hrdina.mokry = false;

  // potřeby (hlad/žízeň/energie) klesají; na nule ubírají zdraví
  for (const p in POTREBY_DEF) {
    const def = POTREBY_DEF[p];
    hrdina.potreby[p] = Math.max(0, (hrdina.potreby[p] || 0) - def.klesa);
    if (hrdina.potreby[p] <= (def.prah || 0) && tik % 20 === 0) {
      zranHrdinu("vyčerpání: " + (def.nazev || p), def.postih || 1);
      if (!hrdina.zivy) return;
    }
  }
  // u vody se dá žízeň hasit sama (stačí stát u břehu)
  if (hrdina.potreby.zizen !== undefined && hrdina.potreby.zizen < 100) {
    if (zde.mat === "voda" || sousedi(h.x, h.y).some(s => s.mat === "voda")) {
      hrdina.potreby.zizen = Math.min(100, hrdina.potreby.zizen + 0.6);
    }
  }
  // spánek na lůžku doplňuje energii a zrychluje čas
  if (hrdina.spanek > 0) {
    hrdina.spanek--;
    if (hrdina.potreby.energie !== undefined) hrdina.potreby.energie = Math.min(100, hrdina.potreby.energie + 1.5);
    if (hrdina.spanek === 0) zapis("🌅 " + hrdina.jmeno + " se probudil odpočatý.");
  }
}

// spojitý pohyb: 60× za vteřinu, směr relativně ke kameře
const drzene = new Set();
window.addEventListener("keydown", e => {
  if (e.target && (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA")) return;
  const k = e.key.toLowerCase();
  if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].indexOf(k) !== -1) e.preventDefault();
  drzene.add(k);
  if (k === "e") akceHrdiny();
  if (k === "q") strel();
  if (k === "x") kopejDolu();
  if (k === " ") skoc();
  // číslice 1..N snědí N-té jídlo z ústavy
  if (/^[1-9]$/.test(k)) { const klice = Object.keys(JIDLO_DEF); const j = klice[parseInt(k) - 1]; if (j) snezJidlo(j); }
  for (const s of STAVBY_DEF) if (s.klavesa === k) postavStavbu(s);
  for (const bd of BUDOVY_DEF) if (bd.klavesa === k) postavBudovu(bd);
});

function snezJidlo(klic) {
  if (!hrdina || !hrdina.zivy) return;
  const def = JIDLO_DEF[klic];
  if (!def) return;
  if ((hrdina.inventar[klic] || 0) <= 0) { zapis("🚫 Nemáš " + (def.nazev || klic) + "."); return; }
  hrdina.inventar[klic]--;
  if (hrdina.potreby.hlad !== undefined) hrdina.potreby.hlad = Math.min(100, hrdina.potreby.hlad + (def.hlad || 0));
  zapis((def.ikona || "🍽️") + " " + hrdina.jmeno + " snědl " + (def.nazev || klic) + " (+" + (def.hlad || 0) + " hlad).");
  if (def.riziko && GenesisCore.rand() < def.riziko) { zranHrdinu("zkažené syrové maso", 1); }
  aktualizujHud();
}
window.addEventListener("keyup", e => drzene.delete(e.key.toLowerCase()));

function skoc() {
  if (!hrdina || !hrdina.zivy || hrdina.stun > 0) return;
  if (hrdina.vyskaSkoku <= 0) { hrdina.rychlostSkoku = 8; hrdina.vyskaSkoku = 0.01; }
}

function strel() {
  if (!hrdina || !hrdina.zivy || hrdina.stun > 0) return;
  if (tik - hrdina.strelCd < 3) return;
  // házíš kámen ze svého batohu — když žádný nemáš, není čím
  if (!(hrdina.inventar.kamen > 0)) { zapis("🚫 Nemáš kámen k hodu — nasbírej ho těžbou (E na kámen)."); return; }
  hrdina.inventar.kamen--;
  hrdina.strelCd = tik;
  hrdina.utok = 10;
  strely.push({ x: hrdina.x, y: hrdina.y, dx: hrdina.smerX, dy: hrdina.smerY, zbyva: 14, z: 1.3 });
  aktualizujHud();
}

function krokStrel() {
  for (const s of strely) {
    s.x += s.dx * 0.4; s.y += s.dy * 0.4;
    s.zbyva -= 0.4; s.z = Math.max(0.2, s.z - 0.025);
    if (s.zbyva <= 0) { s.pryc = true; continue; }
    const c = bunka(Math.floor(s.x), Math.floor(s.y));
    if (c.mat !== "voda" && !maVlastnost(c, "schudne")) { s.pryc = true; continue; }
    for (const b of bytosti) {
      if (!b.zivy || b.spojenec) continue;
      if (Math.hypot(b.x + 0.5 - s.x, b.y + 0.5 - s.y) < 0.8) {
        b.hp -= 1 + efektySoucet().strelba;
        s.pryc = true;
        if (b.hp <= 0) {
          b.zivy = false;
          koristZBytosti(b);
          zapis("🪨 Kámen srazil bytost <b>" + b.typ + "</b>." + (b.xpZa ? " (+" + b.xpZa + " xp)" : ""));
          pridejXp(b.xpZa);
          udalost("zabit_" + b.typ);
        } else zapis("🪨 Kámen zasáhl bytost " + b.typ + " (" + b.hp + " hp).");
        break;
      }
    }
  }
  strely = strely.filter(s => !s.pryc);
}

function muzeStatHrdina(x, y) {
  const r = 0.28;
  let voda = false;
  for (const [ox, oy] of [[-r, -r], [r, -r], [-r, r], [r, r]]) {
    const c = bunka(Math.floor(x + ox), Math.floor(y + oy));
    if (c.mat === "voda") { voda = true; continue; }
    if (!maVlastnost(c, "schudne")) return "zed";
  }
  return voda ? "voda" : "ok";
}

function pohybHrdiny() {
  if (!hrdina) return;
  if (hrdina.utok > 0) hrdina.utok--;
  // svislá fyzika skoku (zárodek modulu skoky-kolize)
  if (hrdina.vyskaSkoku > 0 || hrdina.rychlostSkoku !== 0) {
    hrdina.vyskaSkoku += hrdina.rychlostSkoku * 0.016;
    hrdina.rychlostSkoku -= 24 * 0.016;
    if (hrdina.vyskaSkoku <= 0) { hrdina.vyskaSkoku = 0; hrdina.rychlostSkoku = 0; }
  }
  if (!hrdina.zivy || pauza || hrdina.stun > 0) return;
  let ix = 0, iy = 0;
  if (drzene.has("w") || drzene.has("arrowup")) iy += 1;
  if (drzene.has("s") || drzene.has("arrowdown")) iy -= 1;
  if (drzene.has("a") || drzene.has("arrowleft")) ix -= 1;
  if (drzene.has("d") || drzene.has("arrowright")) ix += 1;
  if (!ix && !iy) return;
  const dl = Math.hypot(ix, iy); ix /= dl; iy /= dl;
  const ef = efektySoucet();
  const pov = POVOLANI_DEF[hrdina.povolani] || {};
  const veVode = bunka(Math.floor(hrdina.x), Math.floor(hrdina.y)).mat === "voda";
  const krok = 5.5 * (pov.rychlost || 1) * ef.rychlost * (veVode ? 0.5 : 1) * 0.016;
  const dx = (smerVpred.x * iy + smerVpravo.x * ix) * krok;
  const dy = (smerVpred.y * iy + smerVpravo.y * ix) * krok;
  const dlS = Math.hypot(dx, dy);
  if (dlS > 0) { hrdina.smerX = dx / dlS; hrdina.smerY = dy / dlS; }
  const zkus = (nx, ny) => {
    const stav = muzeStatHrdina(nx, ny);
    if (stav === "ok") return true;
    if (stav === "voda") {
      if (ef.plavani) return true;
      if (tik - hrdina.posledniZvuk > 15) { hrdina.posledniZvuk = tik; zapis("🌊 " + hrdina.jmeno + " neumí plavat. (dovednost Plavání)"); }
    }
    return false;
  };
  if (zkus(hrdina.x + dx, hrdina.y)) hrdina.x += dx;
  if (zkus(hrdina.x, hrdina.y + dy)) hrdina.y += dy;
}

// kontextová akce (E): dělá to, co dává v daném místě smysl
// obchod: projde nabídky, provede první, na kterou má hráč suroviny
function obchoduj(npc) {
  if (!npc.obchod || !npc.obchod.length) { zapis("🧑‍💼 Obchodník: „Dnes nemám co nabídnout.“"); return; }
  for (const o of npc.obchod) {
    let muze = true;
    for (const k in o.dej) if ((hrdina.inventar[k] || 0) < o.dej[k]) muze = false;
    if (!muze) continue;
    for (const k in o.dej) hrdina.inventar[k] -= o.dej[k];
    for (const k in o.dostan) pridejPredmet(k, o.dostan[k]);
    const za = Object.keys(o.dej).map(k => o.dej[k] + "× " + nazevPredmetu(k)).join(", ");
    const zisk = Object.keys(o.dostan).map(k => o.dostan[k] + "× " + nazevPredmetu(k)).join(", ");
    zapis("🤝 Směna: dal jsi " + za + ", dostal " + zisk + ".");
    aktualizujHud();
    return;
  }
  const seznam = npc.obchod.map(o => Object.keys(o.dej).map(k => o.dej[k] + "× " + nazevPredmetu(k)).join("+") + " → " + Object.keys(o.dostan).map(k => o.dostan[k] + "× " + nazevPredmetu(k)).join("+")).join(" · ");
  zapis("🧑‍💼 Obchodník nabízí: " + seznam + " (nemáš suroviny).");
}

function akceHrdiny() {
  if (!hrdina || !hrdina.zivy || hrdina.stun > 0) return;
  hrdina.utok = 10;
  const h = hrdinaBunka();
  // 0) NPC v dosahu → obchod / rozhovor (mírumilovné nelze omylem zabít akcí)
  for (const b of bytosti) {
    if (b.zivy && b.role && Math.abs(b.x - h.x) + Math.abs(b.y - h.y) <= 1) {
      if (b.role === "obchodnik") { obchoduj(b); return; }
      if (b.role === "strazny") { zapis("💂 Strážný: „Držím tu hlídku, poutníče. Šelmy sem nesmí.“"); return; }
      zapis("🧑‍🌾 Vesničan: „Vítej u nás. Obchodník má železo za kůže.“"); return;
    }
  }
  // 1) nepřítel v dosahu → útok
  for (const b of bytosti) {
    if (b.zivy && b.lovi && !b.mirumilovny && Math.abs(b.x - h.x) + Math.abs(b.y - h.y) <= 1) {
      b.hp -= silaHrdiny();
      if (b.hp <= 0) { b.zivy = false; koristZBytosti(b); zapis("🗡️ <b>" + b.typ + " padl</b> rukou hrdiny." + (b.xpZa ? " (+" + b.xpZa + " xp)" : "")); if (b.boss) zapis("👑 <b>BOSS PORAŽEN!</b>"); pridejXp(b.xpZa); udalost("zabit_" + b.typ); }
      else zapis("🗡️ " + b.typ + " schytal ránu (" + b.hp + " hp).");
      aktualizujHud();
      return;
    }
  }
  // 2) ochočitelné zvíře v dosahu + mám bobule → nakrmit a získat spojence
  for (const b of bytosti) {
    if (b.zivy && !b.spojenec && BYTOSTI_DEF[b.typ] && BYTOSTI_DEF[b.typ].ochocitelny && Math.abs(b.x - h.x) + Math.abs(b.y - h.y) <= 1) {
      if ((hrdina.inventar.bobule || 0) > 0) {
        hrdina.inventar.bobule--;
        b.krmen = (b.krmen || 0) + 1;
        if (b.krmen >= 2) { b.spojenec = true; b.plachy = false; zapis("💚 <b>" + b.typ + " je ochočený</b> — půjde teď za tebou."); }
        else zapis("🫐 Krmíš " + b.typ + "… (ještě jednou a ochočí se)");
        aktualizujHud();
        return;
      }
    }
  }
  // 3) neutrální zvíře (kořist) v dosahu bez bobulí → lov (ne NPC)
  for (const b of bytosti) {
    if (b.zivy && !b.spojenec && !b.lovi && !b.mirumilovny && Math.abs(b.x - h.x) + Math.abs(b.y - h.y) <= 1) {
      b.hp -= silaHrdiny();
      if (b.hp <= 0) { b.zivy = false; koristZBytosti(b); zapis("🏹 Ulovil jsi <b>" + b.typ + "</b>." + (b.xpZa ? " (+" + b.xpZa + " xp)" : "")); pridejXp(b.xpZa); udalost("zabit_" + b.typ); }
      else zapis("🏹 " + b.typ + " zasažen (" + b.hp + " hp).");
      aktualizujHud();
      return;
    }
  }
  // 4) lůžko → spánek
  if (bunka(h.x, h.y).mat === "postel" || sousedi(h.x, h.y).some(s => s.mat === "postel")) {
    hrdina.spanek = 120;
    zapis("😴 " + hrdina.jmeno + " uléhá ke spánku…");
    return;
  }
  // 4) ohniště + syrové maso → upéct
  const uOhniste = bunka(h.x, h.y).mat === "ohniste" || sousedi(h.x, h.y).some(s => s.mat === "ohniste");
  if (uOhniste) {
    for (const klic in JIDLO_DEF) {
      const def = JIDLO_DEF[klic];
      if (def.pece_na && (hrdina.inventar[klic] || 0) > 0) {
        hrdina.inventar[klic]--;
        hrdina.inventar[def.pece_na] = (hrdina.inventar[def.pece_na] || 0) + 1;
        zapis("🍳 Upekl jsi " + (def.nazev || klic) + " → " + (JIDLO_DEF[def.pece_na].nazev || def.pece_na) + ".");
        aktualizujHud();
        return;
      }
    }
  }
  // 5) sousední buňka: sběr z keře, pokácení stromu, těžba kamene/rudy
  for (const [dx, dy] of [[0, -1], [0, 1], [-1, 0], [1, 0]]) {
    const nx = h.x + dx, ny = h.y + dy;
    const c = bunka(nx, ny), m = MATERIALY[c.mat] || {};
    if (m.sber) {
      poloz(nx, ny, "trava");
      const kolik = 2 + Math.floor(GenesisCore.rand() * 3);
      pridejPredmet(m.sber, kolik);
      zapis("🫐 Nasbíral jsi " + kolik + "× " + nazevPredmetu(m.sber) + ".");
      pridejXp(1); aktualizujHud();
      if (HOOKS.poTiku) HOOKS.poTiku();
      return;
    }
    if (c.mat === "strom") {
      poloz(nx, ny, "hlina");
      const zisk = 2 + efektySoucet().drevoNavic;
      hrdina.drevo += zisk;
      zapis("🪓 " + hrdina.jmeno + " pokácel strom (+" + zisk + " 🪵).");
      pridejXp(2); udalost("pokacen_strom"); aktualizujHud();
      if (HOOKS.poTiku) HOOKS.poTiku();
      return;
    }
    // těžba: kámen jde ručně (1 ks), rudy/uhlí jen s potřebným nástrojem
    if (c.mat === "kamen" || maVlastnost(c, "tezitelne")) {
      if (m.potrebaNastroj && !(hrdina.inventar[m.potrebaNastroj] > 0)) {
        zapis("🚫 Na " + (m.nazev || c.mat) + " potřebuješ " + nazevPredmetu(m.potrebaNastroj) + " (vyrob v batohu).");
        return;
      }
      poloz(nx, ny, "hlina");
      if (m.tezi) { for (const k in m.tezi) pridejPredmet(k, m.tezi[k]); zapis("⛏️ Vytěženo: " + Object.keys(m.tezi).map(k => m.tezi[k] + "× " + nazevPredmetu(k)).join(", ") + "."); }
      else { pridejPredmet("kamen", 1); zapis("⛏️ Ulomil jsi kámen (+1 🪨)." + (hrdina.inventar.krumpac ? "" : " S krumpáčem by šlo víc.")); }
      pridejXp(2); udalost("vytezeno_" + c.mat); aktualizujHud();
      if (HOOKS.poTiku) HOOKS.poTiku();
      return;
    }
  }
}

// ---------- podzemní těžba: kopeš dolů vrstvami, hlouběji = vzácnější ----------
// vrstva v dané hloubce (deterministicky) → { mat, dava, xp, nastroj }
function vrstvaVHloubce(x, y, h) {
  if (h >= 12) return { mat: "podlozi", konec: true };
  if (h <= 2) return { mat: "hlina", dava: null, xp: 1 };
  if (h <= 5) return { mat: "kamen", dava: { kamen: 1 }, xp: 2 };
  if (h <= 8) {
    if (hash(x, y, 40 + h) < 0.4) return { mat: "ruda_zelezna", dava: { ruda_zelezna: 1, kamen: 1 }, xp: 4 };
    if (hash(x, y, 50 + h) < 0.3) return { mat: "uhli", dava: { uhli: 2 }, xp: 3 };
    return { mat: "kamen", dava: { kamen: 1 }, xp: 2 };
  }
  // nejhlubší patra: krystaly (potřeba železný krumpáč)
  if (hash(x, y, 60 + h) < 0.35) return { mat: "krystal", dava: { krystal: 1 }, xp: 25, nastroj: "zelezny_krumpac" };
  if (hash(x, y, 70 + h) < 0.4) return { mat: "ruda_zelezna", dava: { ruda_zelezna: 2 }, xp: 5 };
  return { mat: "kamen", dava: { kamen: 1 }, xp: 2 };
}

// kope dolů pod hrdinou (nebo v sousední buňce); snižuje výšku = vzniká šachta
function kopejDolu() {
  if (!hrdina || !hrdina.zivy || hrdina.stun > 0) return;
  if (!(hrdina.inventar.krumpac > 0 || hrdina.inventar.zelezny_krumpac > 0)) {
    zapis("🚫 Na kopání potřebuješ krumpáč (vyrob v batohu: I).");
    return;
  }
  const h = hrdinaBunka();
  const b = bunka(h.x, h.y);
  const novaH = (b.vars.hloubka || 0) + 1;
  const vr = vrstvaVHloubce(h.x, h.y, novaH);
  if (vr.konec) { zapis("🪨 Narazil jsi na skalní podloží — dál to nejde."); return; }
  if (vr.nastroj && !(hrdina.inventar[vr.nastroj] > 0)) {
    zapis("💎 Vidíš třpyt " + (MATERIALY[vr.mat] || {}).nazev + ", ale obyčejný krumpáč nestačí — potřebuješ " + nazevPredmetu(vr.nastroj) + ".");
    return;
  }
  b.vars.hloubka = novaH;
  b.mat = vr.mat;
  b.stavy.clear();
  if (vr.dava) { for (const k in vr.dava) pridejPredmet(k, vr.dava[k]); zapis("⛏️ Hloubka " + novaH + ": " + Object.keys(vr.dava).map(k => vr.dava[k] + "× " + nazevPredmetu(k)).join(", ") + "."); }
  else zapis("⛏️ Kopeš do hloubky " + novaH + "…");
  pridejXp(vr.xp || 1);
  udalost("kopano");
  aktualizujHud();
  if (HOOKS.poTiku) HOOKS.poTiku();
}

// jednotný inventář: suroviny, jídlo i nástroje v hrdina.inventar
function pridejPredmet(klic, n) { hrdina.inventar[klic] = (hrdina.inventar[klic] || 0) + n; }
function nazevPredmetu(klic) { return (PREDMETY_DEF[klic] || JIDLO_DEF[klic] || {}).nazev || klic; }
function ikonaPredmetu(klic) { return (PREDMETY_DEF[klic] || JIDLO_DEF[klic] || {}).ikona || "📦"; }

// výroba z receptu (batoh nebo klávesa)
function vyrob(id) {
  if (!hrdina || !hrdina.zivy) return false;
  const r = RECEPTY_DEF[id];
  if (!r) return false;
  if (r.uOhniste) {
    const h = hrdinaBunka();
    if (!(bunka(h.x, h.y).mat === "ohniste" || sousedi(h.x, h.y).some(s => s.mat === "ohniste"))) { zapis("🚫 " + (r.nazev || id) + " se vyrábí u ohniště."); return false; }
  }
  for (const k in r.potreba) {
    const mam = k === "drevo" ? hrdina.drevo : (hrdina.inventar[k] || 0);
    if (mam < r.potreba[k]) { zapis("🚫 Na " + (r.nazev || id) + " chybí " + nazevPredmetu(k) + " (" + mam + "/" + r.potreba[k] + ")."); return false; }
  }
  for (const k in r.potreba) { if (k === "drevo") hrdina.drevo -= r.potreba[k]; else hrdina.inventar[k] -= r.potreba[k]; }
  pridejPredmet(id, 1);
  zapis((r.ikona || "🔧") + " Vyrobeno: <b>" + (r.nazev || id) + "</b>.");
  aktualizujHud();
  return true;
}

// kořist z ulovené bytosti do inventáře
function koristZBytosti(b) {
  const def = BYTOSTI_DEF[b.typ];
  if (!def || !def.korist) return;
  for (const k in def.korist) pridejPredmet(k, def.korist[k]);
  const seznam = Object.keys(def.korist).map(k => def.korist[k] + "× " + nazevPredmetu(k)).join(", ");
  zapis("🩸 Z kořisti: " + seznam + ".");
}

// stavění řídí ústava: sekce "stavby" (klávesa, materiál, cena, vlastnosti)
function postavStavbu(def) {
  if (!hrdina || !hrdina.zivy || hrdina.stun > 0) return;
  // cena buď v dřevě, nebo v jiné surovině (def.surovina)
  const surKlic = def.surovina || "drevo";
  const cena = def.surovina ? (def.cenaSurovina || 1) : (def.cena || 1);
  const mam = surKlic === "drevo" ? hrdina.drevo : (hrdina.inventar[surKlic] || 0);
  if (mam < cena) { zapis("🚫 Na " + (def.nazev || def.material) + " potřebuješ " + cena + "× " + nazevPredmetu(surKlic) + "."); return; }
  const h = hrdinaBunka();
  const kandidati = [[Math.floor(hrdina.x + hrdina.smerX * 1.3), Math.floor(hrdina.y + hrdina.smerY * 1.3)],
                     [h.x, h.y - 1], [h.x, h.y + 1], [h.x - 1, h.y], [h.x + 1, h.y]];
  for (const [nx, ny] of kandidati) {
    if (nx === h.x && ny === h.y) continue;
    const c = bunka(nx, ny);
    if (!(maVlastnost(c, "schudne") || (def.naVodu && c.mat === "voda"))) continue;
    poloz(nx, ny, def.material);
    if (def.zapalit) { const nb = bunka(nx, ny); nb.stavy.add("horici"); nb.stavy.add("zkroceny"); }
    if (surKlic === "drevo") hrdina.drevo -= cena; else hrdina.inventar[surKlic] -= cena;
    hrdina.utok = 10;
    zapis("🔨 " + hrdina.jmeno + " postavil: <b>" + (def.nazev || def.material) + "</b>.");
    udalost("postaveno_" + def.material);
    aktualizujHud();
    if (HOOKS.poTiku) HOOKS.poTiku();
    return;
  }
  zapis("🚫 Není kam stavět — otoč se jinam.");
}

// blueprint: postaví celou budovu podle vzoru z ústavy (sekce "budovy")
function postavBudovu(def) {
  if (!hrdina || !hrdina.zivy || hrdina.stun > 0) return;
  if (hrdina.drevo < (def.cena || 0)) { zapis("🚫 Na " + (def.nazev || "budovu") + " potřebuješ " + def.cena + " 🪵 (máš " + hrdina.drevo + ")."); return; }
  const vzor = def.vzor, leg = def.legenda || {};
  const h = hrdinaBunka();
  // levý horní roh před hrdinou (aby stavěl "od sebe")
  const ox = h.x + Math.round(hrdina.smerX * 2) - Math.floor(vzor[0].length / 2);
  const oy = h.y + Math.round(hrdina.smerY * 2);
  // kontrola: nestavět na vodu/nepřekonatelné
  for (let ry = 0; ry < vzor.length; ry++) for (let rx = 0; rx < vzor[ry].length; rx++) {
    if (vzor[ry][rx] === ".") continue;
    const c = bunka(ox + rx, oy + ry);
    if (c.mat === "voda") { zapis("🚫 Tady se stavět nedá (voda) — otoč se na souš."); return; }
  }
  for (let ry = 0; ry < vzor.length; ry++) for (let rx = 0; rx < vzor[ry].length; rx++) {
    const znak = vzor[ry][rx];
    if (znak === "." || !leg[znak]) continue;
    poloz(ox + rx, oy + ry, leg[znak]);
  }
  hrdina.drevo -= (def.cena || 0);
  zapis("🏠 " + hrdina.jmeno + " postavil: <b>" + (def.nazev || "budovu") + "</b>!");
  udalost("postavena_budova");
  aktualizujHud();
  if (HOOKS.poTiku) HOOKS.poTiku();
}

// ---------- panely ----------
function aktualizujHud() {
  const el = document.getElementById("hrdinaHud");
  if (!el || !hrdina) return;
  const stavy = [];
  if (hrdina.stun > 0) stavy.push("⚡ ochromen");
  if (hrdina.mokry) stavy.push("💧 mokrý");
  const pov = POVOLANI_DEF[hrdina.povolani] || {};
  let html = (svet.noc ? "🌙 " : "") + (pov.emoji || "🧑") + " <b>" + hrdina.jmeno + "</b><br>" +
    "❤️".repeat(Math.max(0, hrdina.hp)) + "🖤".repeat(Math.max(0, hrdina.maxHp - hrdina.hp)) +
    " &nbsp;🪵 " + hrdina.drevo +
    " &nbsp;·&nbsp; úroveň <b>" + rod.uroven + "</b> (" + rod.xp + "/" + (60 * rod.uroven) + " xp)" +
    (rod.body ? " &nbsp;·&nbsp; 🌟 body: " + rod.body : "");
  // potřeby jako mini-ukazatele
  const pot = [];
  for (const p in POTREBY_DEF) {
    const v = Math.round(hrdina.potreby[p] || 0), d = POTREBY_DEF[p];
    const barva = v < 25 ? "#e0906e" : (v < 55 ? "#d8b46e" : "#8fd18f");
    pot.push((d.ikona || "") + '<span style="color:' + barva + '">' + v + '</span>');
  }
  if (pot.length) html += "<br>" + pot.join(" &nbsp; ");
  // vybavení (nošené brnění/zbraň)
  const vyb = vybaveni(); const nese = [];
  if (vyb.telo) nese.push(vyb.telo.def.ikona + " " + vyb.telo.def.nazev);
  if (vyb.ruka) nese.push(vyb.ruka.def.ikona + " " + vyb.ruka.def.nazev);
  const ef = efektySoucet();
  if (ef.obrana) nese.push("🛡 obrana " + ef.obrana);
  if (nese.length) html += "<br>" + nese.join(" &nbsp; ");
  // inventář (jen nenulové, kromě nošeného vybavení)
  const inv = [];
  for (const k in hrdina.inventar) if (hrdina.inventar[k] > 0) inv.push(((PREDMETY_DEF[k] || JIDLO_DEF[k] || {}).ikona || "📦") + " " + hrdina.inventar[k]);
  const spoj = bytosti.filter(b => b.spojenec && b.zivy).length;
  if (spoj) inv.push("💚 " + spoj);
  if (inv.length) html += "<br>" + inv.join(" &nbsp; ");
  if (hrdina.spanek > 0) html += "<br>😴 spí…";
  if (stavy.length) html += "<br>" + stavy.join(" ");
  if (pamatnik.length) html += "<br>🪦 Památník: " + pamatnik.slice(-2).join(", ") + (pamatnik.length > 2 ? " (+" + (pamatnik.length - 2) + ")" : "");
  el.innerHTML = html;
}

function vykresliPovolani() {
  const el = document.getElementById("povolaniRadek");
  if (!el) return;
  el.innerHTML = "";
  for (const nazev in POVOLANI_DEF) {
    const p = POVOLANI_DEF[nazev];
    const b = document.createElement("button");
    b.textContent = (p.emoji || "") + " " + nazev;
    b.title = p.popis || "";
    if (nazev === zvolenePovolani) b.classList.add("zapnuto");
    b.addEventListener("click", () => {
      zvolenePovolani = nazev;
      zapis("🎭 Příští rekrut bude povoláním <b>" + nazev + "</b> — " + (p.popis || ""));
      vykresliPovolani();
    });
    el.appendChild(b);
  }
}

function vykresliQuesty() {
  const el = document.getElementById("questy");
  if (!el) return;
  el.innerHTML = "";
  for (const q of QUESTY_DEF) {
    const s = questStav[q.id] || { pocet: 0, hotovo: false };
    const d = document.createElement("div");
    d.className = "quest" + (s.hotovo ? " hotovo" : "");
    d.innerHTML = (s.hotovo ? "✅ " : "▫️ ") + "<b>" + q.nazev + "</b> (" + Math.min(s.pocet, q.pocet) + "/" + q.pocet + ")<br><span class=\"qp\">" + q.popis + "</span>";
    el.appendChild(d);
  }
}

function vykresliDovednosti() {
  const el = document.getElementById("dovednosti");
  if (!el) return;
  el.innerHTML = "";
  for (const d of DOVEDNOSTI_DEF) {
    const ma = rod.dovednosti.indexOf(d.id) !== -1;
    const reqOk = (d.vyzaduje || []).every(r => rod.dovednosti.indexOf(r) !== -1);
    const radek = document.createElement("div");
    radek.className = "dovednost";
    if (ma) {
      radek.innerHTML = "✔️ <b>" + d.nazev + "</b> — " + d.popis;
    } else {
      radek.innerHTML = (reqOk ? "" : "🔒 ") + "<b>" + d.nazev + "</b> (" + d.cena + "🌟) — " + d.popis + " ";
      const btn = document.createElement("button");
      btn.textContent = "naučit";
      btn.disabled = !reqOk || rod.body < d.cena;
      btn.addEventListener("click", () => kupDovednost(d.id));
      radek.appendChild(btn);
    }
    el.appendChild(radek);
  }
}

// ---------- kronika a ústava v panelu ----------
function zapis(html) {
  const el = document.getElementById("log");
  if (!el) return;
  const radek = document.createElement("div");
  radek.innerHTML = "<span class=\"cas\">t" + Math.floor(tik / 5) + "</span>" + html;
  el.prepend(radek);
  while (el.children.length > 80) el.removeChild(el.lastChild);
}

function zapisZakona(zakon, text) {
  const posledni = posledniLog[zakon.id] || -999;
  if (tik - posledni < 25) return;
  posledniLog[zakon.id] = tik;
  zapis(text);
}

function vykresliUstavu() {
  const el = document.getElementById("zakony");
  if (!el) return;
  el.innerHTML = "";
  for (const z of ZAKONY) {
    const d = document.createElement("div");
    d.className = "zakon";
    d.dataset.id = z.id;
    d.innerHTML = "<span class=\"zid\">" + z.id + "</span> — " + z.popis;
    el.appendChild(d);
  }
}

setInterval(() => {
  document.querySelectorAll(".zakon").forEach(el => {
    const kdy = poslednePusobil[el.dataset.id] || -999;
    el.classList.toggle("pusobi", tik - kdy < 12);
  });
}, 400);

// ---------- nástroje (klik do světa řeší renderer, sem posílá souřadnice) ----------
function klikNaBunku(x, y) {
  const b = bunka(x, y);
  const nazev = (MATERIALY[b.mat] || {}).nazev || b.mat;
  if (nastroj === "prozkoumat") {
    const stavy = b.stavy.size ? Array.from(b.stavy).join(", ") : "žádné";
    zapis("🔍 <b>" + nazev + "</b> [" + x + "," + y + "] — stavy: " + stavy +
      " | vlhkost " + b.vars.vlhkost + ", palivo " + b.vars.palivo + ", hniloba " + b.vars.hniloba);
    // kauzalita: proč je tady tenhle stav (a proč tu leží mrtvé zvíře)
    const mrtva = bytosti.find(bt => !bt.zivy && bt._u && Math.floor(bt.x) === x && Math.floor(bt.y) === y);
    const uid = mrtva ? mrtva._u : b._u;
    if (uid) {
      const ret = GenesisCore.kauzalita(uid, 40);
      // zkrátit popisy (první věta) a slučovat opakující se kroky
      const slouceno = [];
      for (const u of ret) {
        const txt = u.popis.split(/[.(]/)[0].trim();
        if (slouceno.length && slouceno[slouceno.length - 1].txt === txt) slouceno[slouceno.length - 1].n++;
        else slouceno.push({ txt, n: 1 });
      }
      if (slouceno.length) zapis("🔗 <b>Proč:</b> " + slouceno.map(s => s.txt + (s.n > 1 ? " ×" + s.n : "")).join(" ← "));
    }
  } else if (nastroj === "blesk") {
    b.stavy.add("nabity");
    b.vars.naboj = 5;
    b._u = GenesisCore.udalost("⚡ hráč seslal blesk", x, y, []);
    bleskCas = tik;
    zapis("⚡ <b>Blesk udeřil</b> do materiálu " + nazev + "!");
  } else if (nastroj === "zapalit") {
    if (maVlastnost(b, "horlave") && !b.stavy.has("mokry")) {
      b.stavy.add("horici");
      b._u = GenesisCore.udalost("🔥 hráč zapálil " + nazev, x, y, []);
      zapis("🔥 Zapálil jsi " + nazev + ".");
    } else {
      zapis("🚫 " + nazev + " nejde zapálit" + (b.stavy.has("mokry") ? " — je mokrý." : " — není hořlavý."));
    }
  } else if (nastroj === "polit") {
    b.vars.vlhkost = 6;
    zapis("💧 Polil jsi " + nazev + " vodou.");
  }
}

// ---------- ovládací panel ----------
function prepniDest() {
  svet.prsi = !svet.prsi;
  const btn = document.getElementById("btnDest");
  if (btn) {
    btn.textContent = svet.prsi ? "🌧️ Déšť: ANO" : "🌧️ Déšť: NE";
    btn.classList.toggle("zapnuto", svet.prsi);
  }
  zapis(svet.prsi ? "🌧️ <b>Začalo pršet.</b> A s deštěm chodí blesky…" : "☀️ <b>Přestalo pršet.</b>");
  if (HOOKS.poDesti) HOOKS.poDesti();
}

function pripojUI() {
  document.querySelectorAll(".nastroj").forEach(el => el.addEventListener("click", () => {
    document.querySelectorAll(".nastroj").forEach(e => e.classList.remove("aktivni"));
    el.classList.add("aktivni");
    nastroj = el.dataset.n;
  }));
  const bDest = document.getElementById("btnDest");
  if (bDest) bDest.addEventListener("click", prepniDest);
  const bPauza = document.getElementById("btnPauza");
  if (bPauza) bPauza.addEventListener("click", function () {
    pauza = !pauza;
    this.textContent = pauza ? "▶ Pokračovat" : "⏸ Pauza";
  });
  const bReset = document.getElementById("btnReset");
  if (bReset) bReset.addEventListener("click", () => {
    SEED = Math.floor(Math.random() * 1e9);
    generujSvet();
    zapis("🌍 <b>Nový svět stvořen</b> (seed " + SEED + "). Pravidla, rod i Památník zůstávají.");
    if (HOOKS.poTiku) HOOKS.poTiku();
  });
}

let casovac = null;
function nastavRychlost() {
  if (casovac) clearInterval(casovac);
  const el = document.getElementById("rychlost");
  const v = el ? el.value : 5;
  casovac = setInterval(() => { if (!pauza) krokSimulace(); }, 420 - v * 38);
}

// ---------- bourání/úprava staveb (pravé tlačítko myši) ----------
function jeStavba(mat) { return STAVBY_DEF.some(s => s.material === mat); }
function zbourStavbu(x, y) {
  if (!hrdina || !hrdina.zivy) return;
  const c = bunka(x, y);
  const def = STAVBY_DEF.find(s => s.material === c.mat);
  if (!def) { zapis("🚫 Tady není nic, co bys zboural (jen vlastní stavby)."); return; }
  poloz(x, y, "hlina");
  const vrat = Math.max(1, Math.floor((def.cena || 1) / 2));
  hrdina.drevo += vrat;
  zapis("🔨 Zbořil jsi " + (def.nazev || c.mat) + " (+" + vrat + " 🪵 zpět).");
  aktualizujHud();
  if (HOOKS.poTiku) HOOKS.poTiku();
}

// ---------- hotbar + batoh: modifikovatelný, vše jde i myší ----------
// katalog akcí, které jde přiřadit na sloty hotbaru
function katalogAkci() {
  const a = {
    batoh:  { ik: "🎒", po: "Batoh", fn: otevriBatoh },
    jist:   { ik: "🍽️", po: "Jíst", fn: () => { const j = Object.keys(JIDLO_DEF).find(k => (hrdina.inventar[k] || 0) > 0); if (j) snezJidlo(j); else zapis("🚫 Nemáš co jíst."); } },
    spat:   { ik: "💤", po: "Spát", fn: () => { const h = hrdinaBunka(); if (bunka(h.x, h.y).mat === "postel" || sousedi(h.x, h.y).some(s => s.mat === "postel")) akceHrdiny(); else zapis("🚫 Musíš stát u lůžka (postav ho: B)."); } },
    akce:   { ik: "✋", po: "Akce (E)", fn: akceHrdiny },
    hodit:  { ik: "🪨", po: "Hoď (Q)", fn: strel },
    kopat:  { ik: "⛏️", po: "Kopat (X)", fn: kopejDolu },
    dest:   { ik: "🌧️", po: "Déšť", fn: prepniDest }
  };
  for (const s of STAVBY_DEF) a["stavba_" + s.material] = { ik: "🔨", po: s.nazev || s.material, fn: () => postavStavbu(s) };
  for (const bd of BUDOVY_DEF) a["budova_" + bd.klavesa] = { ik: "🏠", po: bd.nazev || "Budova", fn: () => postavBudovu(bd) };
  return a;
}
const VYCHOZI_HOTBAR = ["batoh", "jist", "spat", "akce", "hodit", "kopat"];

function nactiHotbar() {
  try { const s = JSON.parse(localStorage.getItem("genesis_hotbar")); if (Array.isArray(s) && s.length) return s; } catch {}
  return VYCHOZI_HOTBAR.slice();
}
let hotbarSloty = null;

function postavHotbar() {
  if (document.getElementById("gnHotbar")) return;
  hotbarSloty = nactiHotbar();
  const bar = document.createElement("div");
  bar.id = "gnHotbar";
  document.body.appendChild(bar);
  const styl = document.createElement("style");
  styl.textContent =
    '#gnHotbar{position:fixed;left:50%;bottom:14px;transform:translateX(-50%);display:flex;gap:6px;z-index:47}' +
    '#gnHotbar button{background:#1a2230dd;border:1px solid #3a4658;color:#dde;border-radius:8px;padding:8px 11px;font-family:inherit;font-size:15px;cursor:pointer;min-width:42px;position:relative}' +
    '#gnHotbar button:hover{background:#2a3446}' +
    '#gnHotbar button small{display:block;font-size:9px;color:#8a90a0}' +
    '#gnHotbar button .cfg{position:absolute;top:-6px;right:-6px;font-size:9px;opacity:0;background:#2c6e4f;border-radius:50%;padding:1px 3px}' +
    '#gnHotbar button:hover .cfg{opacity:1}' +
    '#gnBatoh{position:fixed;inset:0;background:rgba(8,10,16,.82);display:none;align-items:center;justify-content:center;z-index:60}' +
    '#gnBatohIn{background:#151a24;border:1px solid #2c3a4e;border-radius:12px;padding:18px 20px;max-width:620px;width:92%;max-height:84vh;overflow-y:auto}' +
    '#gnBatohIn h3{color:#8fd18f;font-size:14px;margin:4px 0 10px;letter-spacing:1px}' +
    '.gnMrizka{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:16px}' +
    '.gnSlot{background:#1e2430;border:1px solid #333e4e;border-radius:8px;padding:8px 10px;min-width:70px;text-align:center;font-size:12px}' +
    '.gnSlot .ik{font-size:22px}.gnSlot .po{color:#9fb0c0}' +
    '.gnRecept{display:flex;align-items:center;gap:10px;background:#1e2430;border:1px solid #333e4e;border-radius:8px;padding:8px 10px;margin-bottom:6px;font-size:12px}' +
    '.gnRecept button,.gnVolba{margin-left:auto;background:#2c6e4f;border:none;color:#fff;border-radius:6px;padding:6px 12px;cursor:pointer}' +
    '.gnVolba{margin:3px;display:inline-block}' +
    '.gnRecept button:disabled{background:#3a3e4e;opacity:.5;cursor:default}' +
    '#gnBatohX{float:right;cursor:pointer;color:#7a8090;font-size:18px}';
  document.head.appendChild(styl);
  vykresliHotbar();

  // batoh overlay (obsah kreslí otevriBatoh)
  const ov = document.createElement("div");
  ov.id = "gnBatoh";
  ov.innerHTML = '<div id="gnBatohIn"><span id="gnBatohX">✕</span><div id="gnBatohObsah"></div></div>';
  document.body.appendChild(ov);
  ov.addEventListener("click", e => { if (e.target === ov) ov.style.display = "none"; });
  document.getElementById("gnBatohX").addEventListener("click", () => ov.style.display = "none");
  window.addEventListener("keydown", e => {
    if (e.target && (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA")) return;
    if (e.key.toLowerCase() === "i") { e.preventDefault(); otevriBatoh(); }
  });
}

function vykresliHotbar() {
  const bar = document.getElementById("gnHotbar");
  if (!bar) return;
  const kat = katalogAkci();
  bar.innerHTML = "";
  hotbarSloty.forEach((id, idx) => {
    const t = kat[id] || { ik: "＋", po: "prázdné", fn: () => {} };
    const b = document.createElement("button");
    b.innerHTML = t.ik + "<small>" + t.po + "</small><span class=\"cfg\">⚙</span>";
    b.title = t.po + " (pravý klik = změnit)";
    b.addEventListener("click", () => { if (hrdina) t.fn(); });
    b.addEventListener("contextmenu", e => { e.preventDefault(); nastavSlot(idx); });
    bar.appendChild(b);
  });
}

// pravý klik na slot → vyber, jakou akci má dělat (uloží se)
function nastavSlot(idx) {
  const kat = katalogAkci();
  const ov = document.getElementById("gnBatoh");
  const el = document.getElementById("gnBatohObsah");
  let html = "<h3>⚙ NASTAV TLAČÍTKO " + (idx + 1) + "</h3><div>";
  for (const id in kat) html += "<button class=\"gnVolba\" data-id=\"" + id + "\">" + kat[id].ik + " " + kat[id].po + "</button>";
  html += "</div>";
  el.innerHTML = html;
  el.querySelectorAll(".gnVolba").forEach(btn => btn.addEventListener("click", () => {
    hotbarSloty[idx] = btn.dataset.id;
    try { localStorage.setItem("genesis_hotbar", JSON.stringify(hotbarSloty)); } catch {}
    vykresliHotbar();
    ov.style.display = "none";
  }));
  ov.style.display = "flex";
}

function otevriBatoh() {
  if (!hrdina) return;
  const ov = document.getElementById("gnBatoh");
  const el = document.getElementById("gnBatohObsah");
  if (!ov || !el) return;
  let html = "<h3>🎒 BATOH</h3><div class=\"gnMrizka\">";
  const polozky = [["drevo", hrdina.drevo]];
  for (const k in hrdina.inventar) if (hrdina.inventar[k] > 0) polozky.push([k, hrdina.inventar[k]]);
  if (polozky.every(p => !p[1])) html += "<div class=\"gnSlot\">prázdno</div>";
  for (const [k, n] of polozky) {
    if (!n) continue;
    const ik = k === "drevo" ? "🪵" : ikonaPredmetu(k);
    html += "<div class=\"gnSlot\"><div class=\"ik\">" + ik + "</div>" + nazevPredmetu(k).replace("drevo", "Dřevo") + "<div class=\"po\">×" + n + "</div></div>";
  }
  html += "</div><h3>🔧 VÝROBA</h3><div id=\"gnRecepty\"></div>";
  el.innerHTML = html;
  const rec = document.getElementById("gnRecepty");
  for (const id in RECEPTY_DEF) {
    const r = RECEPTY_DEF[id];
    const potr = Object.keys(r.potreba).map(k => nazevPredmetu(k).replace("drevo", "Dřevo") + " ×" + r.potreba[k]).join(", ");
    const muze = Object.keys(r.potreba).every(k => (k === "drevo" ? hrdina.drevo : (hrdina.inventar[k] || 0)) >= r.potreba[k]);
    const d = document.createElement("div");
    d.className = "gnRecept";
    d.innerHTML = "<span>" + (r.ikona || "🔧") + " <b>" + (r.nazev || id) + "</b> — " + potr + (r.uOhniste ? " (u ohniště)" : "") + "</span>";
    const btn = document.createElement("button");
    btn.textContent = "Vyrobit";
    btn.disabled = !muze;
    btn.addEventListener("click", () => { if (vyrob(id)) otevriBatoh(); });
    d.appendChild(btn);
    rec.appendChild(d);
  }
  ov.style.display = "flex";
}

// ---------- lišta: Uložit / Načíst / Exportovat (pošli hru dál) ----------
function postavNastroje() {
  if (document.getElementById("gnLista")) return;
  const lista = document.createElement("div");
  lista.id = "gnLista";
  lista.innerHTML =
    '<button id="gnUloz" title="Uložit postup">💾</button>' +
    '<button id="gnNacti" title="Načíst uložený postup">📂</button>' +
    '<button id="gnExport" title="Zabalit celou hru do jednoho souboru a stáhnout — pošli ji komukoli">⬇ Export</button>';
  document.body.appendChild(lista);
  const styl = document.createElement("style");
  styl.textContent =
    '#gnLista{position:fixed;right:16px;bottom:16px;display:flex;gap:6px;z-index:48}' +
    '#gnLista button{background:#1a2230cc;border:1px solid #3a4658;color:#c8d0d8;border-radius:6px;padding:7px 10px;font-family:inherit;font-size:12px;cursor:pointer}' +
    '#gnLista button:hover{background:#2a3242cc}';
  document.head.appendChild(styl);
  document.getElementById("gnUloz").addEventListener("click", ulozHru);
  document.getElementById("gnNacti").addEventListener("click", () => { if (!nactiHru()) zapis("🚫 Žádná uložená hra."); });
  document.getElementById("gnExport").addEventListener("click", exportHry);
}

async function exportHry() {
  zapis("⏳ Balím hru do jednoho souboru…");
  try {
    const [htmlText, coreText, simText, threeText] = await Promise.all([
      fetch(location.pathname).then(r => r.text()),
      fetch("core.js").then(r => r.text()),
      fetch("sim.js").then(r => r.text()),
      fetch("three.min.js").then(r => r.ok ? r.text() : "").catch(() => "")
    ]);
    const ustava = textPravidel || JSON.stringify({ materialy: MATERIALY, zakony: ZAKONY });
    let out = htmlText;
    // vestavěná ústava (hra pak nepotřebuje server ani rules.json)
    const embed = '<script>window.GENESIS_EMBED = ' + JSON.stringify(ustava) + ';<\/script>\n';
    // externí skripty nahradit inline obsahem — VČETNĚ jádra core.js
    if (threeText) out = out.replace(/<script src="three\.min\.js"><\/script>/, () => '<script>' + threeText + '<\/script>');
    out = out.replace(/<script src="core\.js"><\/script>/, () => '<script>' + coreText + '<\/script>');
    out = out.replace(/<script src="sim\.js"><\/script>/, () => embed + '<script>' + simText + '<\/script>');
    // odkazy na ostatní renderery ven (v jednom souboru nedávají smysl)
    out = out.replace(/<span class="nav">[\s\S]*?<\/span>/, "");
    const blob = new Blob([out], { type: "text/html" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "Genesis-hra.html";
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    zapis("✅ <b>Hotovo — stáhla se Genesis-hra.html.</b> Jeden soubor, funguje offline, pošli ho komukoli.");
  } catch (e) {
    zapis("🚫 Export selhal: " + e.message);
  }
}

// ---------- BYOK: vlastní AI klíč (přines si svůj) ----------
const AI_PROVIDERI = { anthropic: "Claude (Anthropic)", openai: "ChatGPT (OpenAI)", gemini: "Gemini (Google)", deepseek: "DeepSeek", server: "serverový klíč" };
function ziskejAI() {
  try { const c = JSON.parse(localStorage.getItem("genesis_ai") || "{}"); return { provider: c.provider || "server", klic: c.klic || "" }; }
  catch { return { provider: "server", klic: "" }; }
}
function nastavAI() {
  const c = ziskejAI();
  const provider = prompt("AI poskytovatel — napiš jeden:\n  anthropic (Claude)\n  openai (ChatGPT)\n  gemini (Google)\n  deepseek\n  server (klíč běžícího serveru)", c.provider);
  if (!provider) return;
  if (!AI_PROVIDERI[provider]) { zapis("🚫 Neznámý poskytovatel „" + provider + "“."); return; }
  let klic = c.klic;
  if (provider !== "server") { klic = prompt("Vlož svůj API klíč pro " + AI_PROVIDERI[provider] + " (drží se jen v tomto prohlížeči):", c.klic || ""); if (klic === null) return; }
  localStorage.setItem("genesis_ai", JSON.stringify({ provider, klic }));
  zapis("⚙ AI nastavena: <b>" + AI_PROVIDERI[provider] + "</b>" + (provider !== "server" ? " (tvůj klíč)" : "") + ".");
}

// ---------- Director Console: napiš záměr, svět se změní ----------
function postavKonzoli() {
  if (document.getElementById("genKonzole")) return;
  const box = document.createElement("div");
  box.id = "genKonzole";
  box.innerHTML =
    '<div id="gkHlava">◈ Director Console <span id="gkStav">…</span><span id="gkAI" title="Nastavit vlastní AI klíč" style="cursor:pointer">⚙</span><span id="gkX">✕</span></div>' +
    '<div id="gkVypis"></div>' +
    '<div id="gkRadek"><input id="gkVstup" placeholder="napiš, jak se má svět chovat… (např. „přidej lávu, která zapaluje a teče“)" autocomplete="off"><button id="gkPosli">▷</button></div>';
  document.body.appendChild(box);
  const styl = document.createElement("style");
  styl.textContent =
    '#genKonzole{position:fixed;left:16px;bottom:16px;width:420px;max-width:90vw;background:#0d1017ee;border:1px solid #2c6e4f;border-radius:8px;font-family:inherit;z-index:50;box-shadow:0 8px 30px #000a;display:none;flex-direction:column}' +
    '#gkHlava{padding:8px 10px;color:#8fd18f;font-size:12px;letter-spacing:1px;border-bottom:1px solid #223;display:flex;align-items:center;gap:8px;cursor:default}' +
    '#gkStav{color:#6a6f7a;font-size:10px;flex:1}' +
    '#gkX{cursor:pointer;color:#6a6f7a}#gkX:hover{color:#e88}' +
    '#gkVypis{max-height:200px;overflow-y:auto;padding:8px 10px;font-size:12px;line-height:1.55;color:#c8d0c8}' +
    '#gkVypis div{padding:2px 0;border-bottom:1px dotted #1c1f28}' +
    '#gkVypis .ja{color:#8fd18f}#gkVypis .ok{color:#8fd18f}#gkVypis .err{color:#e0906e}#gkVypis .cek{color:#d8b46e}' +
    '#gkRadek{display:flex;border-top:1px solid #223}' +
    '#gkVstup{flex:1;background:transparent;border:none;outline:none;color:#e8ece8;font-family:inherit;font-size:13px;padding:10px}' +
    '#gkPosli{background:#2c6e4f;border:none;color:#fff;padding:0 16px;cursor:pointer;font-size:16px}' +
    '#gkPosli:disabled{opacity:.4}' +
    '#gkTlac{position:fixed;left:16px;bottom:16px;background:#1a2c22;border:1px solid #2c6e4f;color:#8fd18f;border-radius:8px;padding:8px 12px;font-family:inherit;font-size:12px;cursor:pointer;z-index:49}';
  document.head.appendChild(styl);

  const tlac = document.createElement("button");
  tlac.id = "gkTlac";
  tlac.textContent = "◈ Director Console";
  tlac.title = "Napiš přirozeným jazykem, jak se má svět chovat";
  document.body.appendChild(tlac);

  const vstup = document.getElementById("gkVstup");
  const posliBtn = document.getElementById("gkPosli");
  const vypis = document.getElementById("gkVypis");
  const otevri = () => { box.style.display = "flex"; tlac.style.display = "none"; vstup.focus(); };
  const zavri = () => { box.style.display = "none"; tlac.style.display = "block"; };
  tlac.addEventListener("click", otevri);
  document.getElementById("gkX").addEventListener("click", zavri);
  // BYOK: vlastní AI klíč (Claude/GPT/Gemini/DeepSeek), drží se jen v prohlížeči
  document.getElementById("gkAI").addEventListener("click", nastavAI);
  window.addEventListener("keydown", e => {
    if (e.key === "\\" && !(e.target && (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA"))) { e.preventDefault(); otevri(); }
    if (e.key === "Escape" && box.style.display === "flex") zavri();
  });

  const radek = (html, tr) => { const d = document.createElement("div"); d.className = tr || ""; d.innerHTML = html; vypis.appendChild(d); vypis.scrollTop = vypis.scrollHeight; return d; };

  fetch("/api/status").then(r => r.json()).then(s => {
    document.getElementById("gkStav").textContent = s.klic ? (s.provider + " · " + s.model) : "bez klíče — spusť ./console.sh";
    if (!s.klic) radek("Konzole běží bez AI. Spusť hru přes <b>./console.sh</b>, aby uměla měnit svět.", "cek");
    else radek("Napiš, jak se má svět chovat. Návrh se před zápisem vyzkouší nasucho — když by svět rozbil, zahodím ho.", "cek");
  }).catch(() => { document.getElementById("gkStav").textContent = "server bez API (jen statika)"; radek("Tenhle server neumí konzoli — spusť <b>./console.sh</b>.", "cek"); });

  async function odesli(vetaArg, potvrdit) {
    const veta = vetaArg || vstup.value.trim();
    if (!veta) return;
    if (!vetaArg) { vstup.value = ""; radek("› " + veta.replace(/</g, "&lt;"), "ja"); }
    posliBtn.disabled = true;
    const cek = radek("⏳ přemýšlím a zkouším svět nasucho…", "cek");
    try {
      const ai = ziskejAI();
      const r = await fetch("/api/rewrite", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ veta, potvrdit: !!potvrdit, provider: ai.provider, klic: ai.klic }) });
      const j = await r.json();
      cek.remove();
      if (j.ok) {
        radek("✅ Hotovo — svět se právě mění. " + (j.zmeny && j.zmeny.pridano.length ? "Přidáno: " + j.zmeny.pridano.join(", ") : ""), "ok");
        if (j.varovani && j.varovani.length) radek("⚠️ " + j.varovani.join(" "), "cek");
        textPravidel = "";   // vynutit okamžité přenačtení ústavy
      } else if (j.cekaPotvrzeni) {
        const d = radek("⚠️ " + j.chyba, "cek");
        const btn = document.createElement("button");
        btn.textContent = "Zapsat i tak";
        btn.style.cssText = "margin-left:6px;background:#8a5a2c;border:none;color:#fff;border-radius:4px;padding:2px 8px;cursor:pointer;font-size:11px";
        btn.addEventListener("click", () => { btn.remove(); odesli(veta, true); });
        d.appendChild(btn);
      } else {
        radek("🚫 " + (j.chyba || "Nepovedlo se.") + (j.detail ? " — " + [].concat(j.detail).join(" ") : ""), "err");
      }
    } catch (e) {
      cek.remove();
      radek("🚫 Konzole není dostupná (běží server ./console.sh?).", "err");
    }
    posliBtn.disabled = false;
    vstup.focus();
  }
  posliBtn.addEventListener("click", odesli);
  vstup.addEventListener("keydown", e => { if (e.key === "Enter") odesli(); });
}

// ---------- time-travel: snímky aktivní oblasti + přehrání do bodu N ----------
// Nekonečný svět nelze ukládat celý → snímkujeme jen okolí hrdiny, v intervalech.
const SNAP_R = 34, SNAP_INTERVAL = 40, SNAP_MAX = 50;
let snimky = [], casovaniAktivni = false;

function udelejSnimek() {
  const h = hrdinaBunka();
  const bunky = [];
  for (let y = h.y - SNAP_R; y < h.y + SNAP_R; y++) for (let x = h.x - SNAP_R; x < h.x + SNAP_R; x++) {
    const b = bunka(x, y);
    bunky.push({ x, y, mat: b.mat, stavy: Array.from(b.stavy), vars: Object.assign({}, b.vars), _u: b._u });
  }
  snimky.push({
    tik: GenesisCore.tik, rng: GenesisCore.rngSnapshot(), stred: { x: h.x, y: h.y }, bunky,
    bytosti: bytosti.map(kopieBytosti),
    hrdina: JSON.parse(JSON.stringify({ x: hrdina.x, y: hrdina.y, hp: hrdina.hp, drevo: hrdina.drevo, potreby: hrdina.potreby, inventar: hrdina.inventar, povolani: hrdina.povolani, jmeno: hrdina.jmeno, zivy: hrdina.zivy })),
    prsi: !!svet.prsi
  });
  if (snimky.length > SNAP_MAX) snimky.shift();
}
function kopieBytosti(b) { const k = Object.assign({}, b); k.stavy = undefined; return k; }

function obnovSnimek(idx) {
  const s = snimky[idx];
  if (!s) return;
  for (const c of s.bunky) {
    const b = bunka(c.x, c.y);
    b.mat = c.mat; b.stavy = new Set(c.stavy); b.vars = Object.assign({}, c.vars); b._u = c._u;
  }
  bytosti = s.bytosti.map(b => Object.assign({}, b));
  Object.assign(hrdina, JSON.parse(JSON.stringify(s.hrdina)));
  GenesisCore.rngRestore(s.rng);
  GenesisCore.tik = s.tik; tik = s.tik;
  svet.prsi = s.prsi;
  aktualizujHud();
  if (HOOKS.poDesti) HOOKS.poDesti();
  if (HOOKS.poTiku) HOOKS.poTiku();
}

function postavCasovyStroj() {
  if (document.getElementById("gtStroj")) return;
  const bar = document.createElement("div");
  bar.id = "gtStroj";
  bar.innerHTML = '<button id="gtBtn" title="Cestovat časem — přehraj svět zpět">🕰 Historie</button>' +
    '<div id="gtPanel"><span id="gtStav">—</span><input type="range" id="gtSlider" min="0" max="0" value="0"><button id="gtZpet">↩ zpět do přítomnosti</button></div>';
  document.body.appendChild(bar);
  const st = document.createElement("style");
  st.textContent =
    '#gtStroj{position:fixed;left:16px;top:64px;z-index:48;font-family:inherit}' +
    '#gtBtn{background:#2a2440cc;border:1px solid #6a5aa0;color:#d8c8f0;border-radius:8px;padding:7px 11px;font-size:12px;cursor:pointer}' +
    '#gtPanel{display:none;margin-top:6px;background:#161326ee;border:1px solid #3a3060;border-radius:8px;padding:10px;width:280px}' +
    '#gtStav{display:block;font-size:11px;color:#b0a8d0;margin-bottom:6px}' +
    '#gtSlider{width:100%;margin-bottom:8px}' +
    '#gtZpet{background:#2c6e4f;border:none;color:#fff;border-radius:6px;padding:6px 10px;font-size:11px;cursor:pointer;width:100%}';
  document.head.appendChild(st);
  const panel = document.getElementById("gtPanel");
  const slider = document.getElementById("gtSlider");
  const stav = document.getElementById("gtStav");
  document.getElementById("gtBtn").addEventListener("click", () => {
    casovaniAktivni = !casovaniAktivni;
    panel.style.display = casovaniAktivni ? "block" : "none";
    if (casovaniAktivni) {
      pauza = true;
      slider.max = Math.max(0, snimky.length - 1);
      slider.value = snimky.length - 1;
      aktualizujCasStav();
    } else { pauza = false; }
  });
  slider.addEventListener("input", () => { obnovSnimek(+slider.value); aktualizujCasStav(); });
  document.getElementById("gtZpet").addEventListener("click", () => {
    if (snimky.length) obnovSnimek(snimky.length - 1);
    casovaniAktivni = false; panel.style.display = "none"; pauza = false;
  });
  function aktualizujCasStav() {
    const s = snimky[+slider.value];
    if (!s) { stav.textContent = "žádné snímky"; return; }
    const kolikZpet = (snimky[snimky.length - 1] ? snimky[snimky.length - 1].tik : 0) - s.tik;
    stav.innerHTML = "⏱ tik <b>" + s.tik + "</b> &nbsp;(" + (kolikZpet === 0 ? "přítomnost" : "−" + kolikZpet + " tiků zpět") + ")<br>snímek " + (+slider.value + 1) + "/" + snimky.length;
  }
  window.aktualizujCasStav = aktualizujCasStav;
}

// ---------- sbalitelné sekce sidebaru (accordion) ----------
// Sidebar CODEXu má hodně sekcí; klik na nadpis je sbalí/rozbalí, ať se to vejde.
function postavHarmoniku() {
  document.querySelectorAll("aside .blok").forEach(blok => {
    const h2 = blok.querySelector("h2");
    if (!h2 || h2.dataset.harm) return;
    h2.dataset.harm = "1";
    h2.style.cursor = "pointer";
    h2.style.userSelect = "none";
    const ind = document.createElement("span");
    ind.textContent = "▾ ";
    ind.style.color = "#5a6070";
    h2.insertBefore(ind, h2.firstChild);
    h2.addEventListener("click", () => {
      const sbaleno = blok.classList.toggle("sbaleno");
      Array.from(blok.children).forEach(el => { if (el !== h2) el.style.display = sbaleno ? "none" : ""; });
      // obsah některých sekcí (Ústava→#zakony, Kronika→#log) je v sousedním divu
      let sib = blok.nextElementSibling;
      while (sib && !sib.classList.contains("blok")) { sib.style.display = sbaleno ? "none" : ""; sib = sib.nextElementSibling; }
      ind.textContent = sbaleno ? "▸ " : "▾ ";
    });
  });
}

// ---------- start ----------
async function startGenesis(hooks) {
  HOOKS = hooks || {};
  GenesisCore.config({ seed: SEED });
  GenesisCore.setGenerator(teren);      // biomový generátor CODEXu → jádro
  await nactiPravidla(true);
  generujSvet();
  pripojUI();
  document.getElementById("rychlost").addEventListener("input", nastavRychlost);
  nastavRychlost();
  postavKonzoli();
  postavNastroje();
  postavHotbar();
  postavCasovyStroj();
  postavHarmoniku();
  setInterval(() => { pohybHrdiny(); krokStrel(); }, 16);
  setInterval(() => { if (hrdina && hrdina.zivy && tik > 30) try { ulozHruTiche(); } catch (e) {} }, 30000);
  const stavbyText = STAVBY_DEF.map(s => "<b>" + s.klavesa.toUpperCase() + "</b> " + (s.nazev || s.material)).join(" · ");
  zapis("🌍 <b>Svět stvořen.</b> Je nekonečný — vzniká tam, kam jdeš. Ústava má " + ZAKONY.length + " zákonů, " +
    QUESTY_DEF.length + " úkolů a " + DOVEDNOSTI_DEF.length + " dovedností. " +
    "<b>WASD</b> pohyb · <b>mezerník</b> skok · <b>E</b> udeř/kácej · <b>Q</b> hoď kámen · stavby: " + stavbyText + ". Boss čeká na jihovýchodě.");
  if (HOOKS.poStartu) HOOKS.poStartu();
}

"use strict";
// ============================================================
// GENESIS CORE — generický simulační engine.
// Nezná DOM, hrdinu, souboj ani žádnou konkrétní hru. Umí:
//   • deterministický svět po chuncích s injektovaným generátorem
//   • RNG + hodnotový šum
//   • interpret zákonů nad materiály/vlastnostmi/stavy (ústava)
//   • hooky/eventy pro komunikaci s okolím (log, změny…)
// Hra ani renderer nikdy nesahají do vnitřků — jen přes toto API.
// ============================================================
const GenesisCore = (function () {

  const cfg = { chunk: 32, seed: 20260715 };
  let MATERIALY = {}, ZAKONY = [];
  let generator = (x, y) => "prazdno";        // hra musí dodat vlastní
  const chunky = new Map();
  const world = {};                            // globální stav světa (prší, noc, …)
  let tik = 0;
  const hooks = {};

  // ---------- RNG & šum (deterministické podle seedu) ----------
  function hash(x, y, s) {
    let h = (x | 0) * 374761393 + (y | 0) * 668265263 + ((s | 0) * 1442695041) + cfg.seed;
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    h ^= h >>> 16;
    return (h >>> 0) / 4294967296;
  }
  // deterministický proud náhody (mulberry32). Stejný seed → stejná posloupnost →
  // reprodukovatelný svět. Stav je součástí světa (kvůli replay/save/time-travel).
  let rngState = cfg.seed >>> 0;
  function seedRng(s) { rngState = s >>> 0; }
  function rand() {
    rngState = (rngState + 0x6D2B79F5) | 0;
    let t = rngState;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  const lerp = (a, b, t) => a + (b - a) * t;
  const hladky = t => t * t * (3 - 2 * t);
  function noise(x, y, meritko, s) {
    const fx = x / meritko, fy = y / meritko;
    const x0 = Math.floor(fx), y0 = Math.floor(fy);
    const tx = hladky(fx - x0), ty = hladky(fy - y0);
    return lerp(lerp(hash(x0, y0, s), hash(x0 + 1, y0, s), tx),
                lerp(hash(x0, y0 + 1, s), hash(x0 + 1, y0 + 1, s), tx), ty);
  }

  // ---------- svět ----------
  let cellInit = null;   // hra může doplnit vlastní proměnné do každé buňky
  function novaBunka(mat) {
    const m = MATERIALY[mat] || {};
    const b = { mat: mat, stavy: new Set(), vars: { palivo: m.palivo || 0 }, _u: null };
    if (cellInit) cellInit(b);
    return b;
  }

  // ---------- historie / kauzalita (event sourcing, ohraničené) ----------
  // Každá významná změna světa = událost s odkazem na svou příčinu. Vzniká řetěz
  // „proč se to stalo". Ohraničeno (nekonečný svět nelze ukládat celý).
  let historie = new Map();       // id -> {id, tik, x, y, popis, priciny:[id]}
  let udalostId = 0;
  const HIST_MAX = 6000;
  function udalost(popis, x, y, priciny) {
    const id = ++udalostId;
    historie.set(id, { id, tik, x: x, y: y, popis, priciny: (priciny || []).filter(p => p != null) });
    if (historie.size > HIST_MAX) { const nej = udalostId - HIST_MAX; for (const k of historie.keys()) { if (k <= nej) historie.delete(k); else break; } }
    emit("udalost", historie.get(id));
    return id;
  }
  // řetěz příčin od dané události nahoru (nejnovější → nejstarší), bez cyklů
  function kauzalita(id, max) {
    const retez = [], videno = new Set();
    let fronta = [id];
    while (fronta.length && retez.length < (max || 40)) {
      const cur = fronta.shift();
      if (cur == null || videno.has(cur)) continue;
      videno.add(cur);
      const u = historie.get(cur);
      if (!u) continue;
      retez.push(u);
      for (const p of u.priciny) fronta.push(p);
    }
    return retez;
  }
  function klic(cx, cy) { return cx + "," + cy; }
  function generujChunk(cx, cy) {
    const K = cfg.chunk, bunky = new Array(K * K);
    for (let ly = 0; ly < K; ly++) for (let lx = 0; lx < K; lx++)
      bunky[ly * K + lx] = novaBunka(generator(cx * K + lx, cy * K + ly));
    const c = { cx, cy, bunky };
    chunky.set(klic(cx, cy), c);
    emit("chunk", c);
    return c;
  }
  function chunk(cx, cy) { return chunky.get(klic(cx, cy)) || generujChunk(cx, cy); }
  function cell(x, y) {
    const K = cfg.chunk, cx = Math.floor(x / K), cy = Math.floor(y / K);
    return chunk(cx, cy).bunky[(y - cy * K) * K + (x - cx * K)];
  }
  function place(x, y, mat) {
    const K = cfg.chunk, cx = Math.floor(x / K), cy = Math.floor(y / K);
    chunk(cx, cy).bunky[(y - cy * K) * K + (x - cx * K)] = novaBunka(mat);
  }
  function neighbors(x, y) { return [cell(x, y - 1), cell(x, y + 1), cell(x - 1, y), cell(x + 1, y)]; }

  // ---------- interpret zákonů ----------
  function hasProp(b, v) { const m = MATERIALY[b.mat]; return !!(m && m.vlastnosti && m.vlastnosti.indexOf(v) !== -1); }

  let _snap = null;   // při synchronním kroku: snapshot pro čtení sousedů ze STARÉHO stavu
  function ctiSouseda(x, y) { if (_snap) { const s = _snap.get(x + "," + y); if (s) return s; } return cell(x, y); }

  function splnuje(b, pod, x, y) {
    if (!pod) return true;
    if (pod.material) { const a = [].concat(pod.material); if (a.indexOf(b.mat) === -1) return false; }
    if (pod.vlastnost) { for (const v of [].concat(pod.vlastnost)) if (!hasProp(b, v)) return false; }
    if (pod.neVlastnost) { for (const v of [].concat(pod.neVlastnost)) if (hasProp(b, v)) return false; }
    if (pod.stav) { for (const s of [].concat(pod.stav)) if (!b.stavy.has(s)) return false; }
    if (pod.neStav) { for (const s of pod.neStav) if (b.stavy.has(s)) return false; }
    if (pod.var) for (const jm in pod.var) {
      const test = pod.var[jm], v = b.vars[jm] || 0;
      for (const op in test) { const c = test[op];
        if (op === ">=" && !(v >= c)) return false;
        if (op === "<=" && !(v <= c)) return false;
        if (op === ">"  && !(v > c))  return false;
        if (op === "<"  && !(v < c))  return false;
        if (op === "="  && !(v === c)) return false; }
    }
    if (pod.aspon_jedno) { let ok = false; for (const alt of pod.aspon_jedno) if (splnuje(b, alt, x, y)) { ok = true; break; } if (!ok) return false; }
    // počet sousedů (8 okolních, Moore) splňujících kritérium — pro celulární automaty
    if (pod.sousede && x !== undefined) {
      let n = 0;
      for (const [dx, dy] of [[-1,-1],[0,-1],[1,-1],[-1,0],[1,0],[-1,1],[0,1],[1,1]])
        if (splnuje(ctiSouseda(x + dx, y + dy), pod.sousede.co)) n++;
      const t = pod.sousede.pocet;
      if (t) for (const op in t) { const c = t[op];
        if (op === ">=" && !(n >= c)) return false; if (op === "<=" && !(n <= c)) return false;
        if (op === ">" && !(n > c)) return false; if (op === "<" && !(n < c)) return false; if (op === "=" && !(n === c)) return false; }
    }
    return true;
  }

  function proved(b, efekty, zakon, ctx) {
    ctx = ctx || {};
    const pricina = ctx.spoustec ? ctx.spoustec._u : (b._u || null);
    for (const ef of efekty) {
      let vyznamne = false;   // významná = viditelná změna → zapíše se do historie
      if (ef.pridejStav) { if (!b.stavy.has(ef.pridejStav)) vyznamne = true; b.stavy.add(ef.pridejStav); }
      if (ef.odeberStav) { if (b.stavy.has(ef.odeberStav)) vyznamne = true; b.stavy.delete(ef.odeberStav); }
      if (ef.zmenVar) for (const jm in ef.zmenVar) {
        b.vars[jm] = (b.vars[jm] || 0) + ef.zmenVar[jm];
        if (ef.strop && ef.strop[jm] !== undefined) b.vars[jm] = Math.min(b.vars[jm], ef.strop[jm]);
        if (ef.dno && ef.dno[jm] !== undefined) b.vars[jm] = Math.max(b.vars[jm], ef.dno[jm]);
      }
      if (ef.nastavVar) for (const jm in ef.nastavVar) b.vars[jm] = ef.nastavVar[jm];
      if (ef.promenNa) {
        const stary = (MATERIALY[b.mat] || {}).nazev || b.mat;
        b.mat = ef.promenNa; b.stavy.clear();
        b.vars.palivo = (MATERIALY[ef.promenNa] || {}).palivo || 0;
        b._u = udalost((zakon.popis || zakon.id) + " (" + stary + "→" + ((MATERIALY[ef.promenNa]||{}).nazev||ef.promenNa) + ")", ctx.x, ctx.y, [pricina]);
        if (ef.log) emit("log", { text: ef.log.replace("{material}", stary), zakon });
        continue;
      }
      // do historie jen dramatické zákony (ty, co mají log) — ne déšť/vysychání
      if (vyznamne && ef.log) b._u = udalost(zakon.popis || zakon.id, ctx.x, ctx.y, [pricina]);
      if (ef.log) emit("log", { text: ef.log.replace("{material}", (MATERIALY[b.mat] || {}).nazev || b.mat), zakon });
    }
  }

  // jeden krok zákonů nad obdélníkovou oblastí {x0,y0,x1,y1}
  function step(oblast) {
    tik++;
    // synchronní režim (celulární automaty): všechny buňky se mění NARÁZ podle starého stavu
    if (world.synchronni) return stepSynchronni(oblast);
    for (const z of ZAKONY) {
      if (z.svet) { let ok = true; for (const k in z.svet) if (world[k] !== z.svet[k]) ok = false; if (!ok) continue; }
      for (let y = oblast.y0; y < oblast.y1; y++) for (let x = oblast.x0; x < oblast.x1; x++) {
        const b = cell(x, y);
        if (!splnuje(b, z.kdyz, x, y)) continue;
        if (z.cil === "soused") {
          const sous = [[x, y - 1], [x, y + 1], [x - 1, y], [x + 1, y]];
          for (const [sx, sy] of sous) {
            const s = cell(sx, sy);
            if (!splnuje(s, z.pokud, sx, sy)) continue;
            if (z.sance !== undefined && rand() > z.sance) continue;
            proved(s, z.udelej, z, { x: sx, y: sy, spoustec: b });   // příčina = buňka co spustila
          }
        } else {
          if (z.sance !== undefined && rand() > z.sance) continue;
          proved(b, z.udelej, z, { x: x, y: y, spoustec: b });
        }
      }
    }
    emit("tik", tik);
  }

  function stepSynchronni(oblast) {
    // 1) snapshot stavu (mat+stavy) pro čtení sousedů
    _snap = new Map();
    for (let y = oblast.y0 - 1; y <= oblast.y1; y++) for (let x = oblast.x0 - 1; x <= oblast.x1; x++) {
      const b = cell(x, y);
      _snap.set(x + "," + y, { mat: b.mat, stavy: new Set(b.stavy), vars: b.vars });
    }
    // 2) nasbírej změny proti snapshotu (nezapisuj hned)
    const zmeny = [];
    for (const z of ZAKONY) {
      if (z.svet) { let ok = true; for (const k in z.svet) if (world[k] !== z.svet[k]) ok = false; if (!ok) continue; }
      for (let y = oblast.y0; y < oblast.y1; y++) for (let x = oblast.x0; x < oblast.x1; x++) {
        const snapB = _snap.get(x + "," + y);
        if (!splnuje(snapB, z.kdyz, x, y)) continue;
        if (z.sance !== undefined && rand() > z.sance) continue;
        zmeny.push({ x, y, udelej: z.udelej, z });
      }
    }
    _snap = null;
    // 3) aplikuj naráz na živé buňky
    for (const zm of zmeny) proved(cell(zm.x, zm.y), zm.udelej, zm.z, { x: zm.x, y: zm.y, spoustec: cell(zm.x, zm.y) });
    emit("tik", tik);
  }

  // ---------- hooky ----------
  function on(ev, fn) { (hooks[ev] || (hooks[ev] = [])).push(fn); }
  function emit(ev, data) { const a = hooks[ev]; if (a) for (const fn of a) fn(data); }

  // ---------- ústava & konfigurace ----------
  function loadRules(data) {
    MATERIALY = data.materialy || {};
    ZAKONY = data.zakony || [];
    emit("rules", data);
  }
  function config(o) { if (o.chunk) cfg.chunk = o.chunk; if (o.seed !== undefined) { cfg.seed = o.seed; seedRng(o.seed); } }
  function reset() { chunky.clear(); tik = 0; seedRng(cfg.seed); historie.clear(); udalostId = 0; }
  // stav RNG ven/dovnitř — kvůli save a budoucímu time-travel (replay do bodu N)
  function rngSnapshot() { return rngState; }
  function rngRestore(s) { rngState = s >>> 0; }

  return {
    config, setGenerator: fn => generator = fn, setCellInit: fn => cellInit = fn, loadRules, reset,
    hash, noise, rand, seedRng, rngSnapshot, rngRestore,
    cell, place, neighbors, novaBunka, hasProp, splnuje, proved, step,
    udalost, kauzalita, historie: () => historie,
    on, emit, world,
    get tik() { return tik; }, set tik(v) { tik = v; }, get CHUNK() { return cfg.chunk; },
    materials: () => MATERIALY, laws: () => ZAKONY, chunks: () => chunky
  };
})();

if (typeof module !== "undefined") module.exports = GenesisCore;

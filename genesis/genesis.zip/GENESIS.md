# GENESIS — architektura, stav a roadmapa

*Jednotný model **stavu** světa. Vývojář popisuje zákony, ne algoritmy. Renderer jen kreslí stav; význam drží ústava.*

> „Neměníme způsob, jakým počítač vykonává kód. Měníme způsob, jakým člověk popisuje svět."

Genesis je k herním enginům tím, čím je SQL k databázím, nebo **Datomic k datům: databáze, která má čas.** Ne engine na jednu hru — společná vrstva, nad kterou vzniká libovolně mnoho simulací.

---

## Architektura (4 vrstvy + historie)

```
   Language     ústava = deklarativní popis světa (materiály, vlastnosti, zákony, entity)
      ↓
   Compiler     text/JSON/přirozený jazyk (LLM) → validace → sandbox → schválení → zápis
      ↓          (LLM je JEN zde, v návrhu — NIKDY v běhu)
   Runtime      deterministický interpret zákonů nad stavem světa   ← core.js
      ↓
   Historie     append-only řetěz událostí (event sourcing) → kauzalita, time-travel
      ↓
 Presentation   renderer / SDK / analytika — jen zobrazuje stav, není zdroj pravdy
```

**Jediný zdroj pravdy = stav světa.** Fyzika, AI, questy, ekonomika i renderer z něj *čtou*, žádný si ho nekopíruje. Renderer nepotřebuje význam — potřebuje stav.

---

## Stav implementace (2026-07-16)

| Vrstva | Stav | Kde |
|---|---|---|
| Language — ústava (materiály/vlastnosti/zákony/bytosti/…) | ✅ funguje | `rules.json`, `zivot-rules.json` |
| Runtime — jádro (svět po chuncích, RNG, interpret zákonů, hooky) | ✅ čisté, bez DOM/hry | `core.js` |
| Runtime — **determinismus** (seedovaný RNG, stejný seed → stejný svět) | ✅ **hotovo + ověřeno** | `core.js` (mulberry32) |
| Historie — **kauzální graf** (proč se co stalo, řetěz příčin) | ✅ **hotovo + ověřeno** | `core.js` (event sourcing) |
| Historie — **time-travel „přehraj zpět"** (snímky + obnova) | ✅ **hotovo + ověřeno** | `sim.js` (🕰 Historie) |
| Compiler — Director Console (věta → ústava → validace → zápis) | ✅ funguje | `console-server.mjs` |
| Compiler — **AI orchestrátor** (multi-modal: text/obrázek/hlas, BYOK, workflow) | ✅ hotovo | `ai.js`, `ai-studio.html` |
| Assety — obrázky/textury/portréty do her (AI i vlastní upload) | ✅ 2D hotovo | `assets.js` |
| Assety — 3D modely + animace (Blender → glTF) | ⏳ upload+úložiště ✅, render čeká na modulovou migraci | `assets.js` |
| Verzování — **git repozitář** | ✅ hotovo | lokální `.git` |
| Compiler — validátor (běh nasucho + kontrola dle spec + verzování) | ✅ funguje | `validate.mjs` |
| Language — **Constitution Specification v0.1** (formát ústavy) | ✅ **hotovo** | `CONSTITUTION.md` |
| Presentation — CODEX ve 3 pohledech + karetní souboj | ✅ funguje | `index*.html`, `text.html`, `souboj.html` |
| Presentation — Ekosystém (druhý prototyp nad týmž jádrem) | ✅ funguje | `zivot.html` |
| Presentation — Game of Life (třetí preset, onboarding) | ✅ funguje | `life.html` |
| Presentation — generický renderer (libovolná ústava) | ✅ funguje | `generic.html` |
| **Jedno jádro, TŘI hry** (CODEX/Ekosystém/Life na `core.js`) | ✅ **dokázáno** | — |
| Runtime — synchronní krok + počítání sousedů (celulární automaty) | ✅ hotovo | `core.js` |
| Time-travel „co kdyby" (kontrafaktuál, větvení) | ⏳ pozdější (dražší) | — |
| Presentation — **Genesis Studio** (IDE: chat + náhled + inspektor + pluginy) | ✅ **hotovo** | `studio.html` |
| Compiler — **diff-safety** (varuje před tichým smazáním) + verzovaná historie ústavy | ✅ **hotovo** | `console-server.mjs` |
| Distribuce — **single-file export** (jádro+hra+ústava, offline) | ✅ **opraveno** | `build-export.mjs` |
| SDK / Desktop (Tauri) / otevřený formát | ⏳ další krok | — |

---

## Roadmapa (pořadí podle závislostí, ne kalendáře)

1. **Determinismus** ✅ — nutná podmínka pro vše níže. *Hotovo.*
2. **Kauzální graf / historie** ✅ — append-only řetěz „proč se co stalo" (event sourcing, ohraničený na 6000 událostí). Každá dramatická změna (proměna materiálu, oheň, blesk, smrt) nese odkaz na příčinu. V CODEXu: nástroj 🔍 na buňku/mrtvé zvíře → vypíše řetěz „Proč: … ← … ← hráč zapálil". *Killer feature — žádný velký engine ji nemá. Hotovo + ověřeno.*
3. **Time-travel „přehraj zpět"** ✅ — snímky aktivní oblasti (±34 kolem hrdiny, á 40 tiků, max 50 snímků ≈ 2000 tiků historie) + obnova stavu včetně RNG. V CODEXu: 🕰 Historie → posuvník časem. Přesnost = interval snímků; omezeno na okolí hrdiny (nekonečný svět nelze ukládat celý). *Hotovo + ověřeno.*
   - *„Co kdyby strom nespadl?"* (kontrafaktuál = re-simulace od větve) je pozdější, výrazně dražší výzkum — slibovat odděleně.
4. **Constitution Specification v0.1** ✅ — **deskriptivní** formát ústavy (`CONSTITUTION.md`): jádrová část (materiály/zákony, co interpretuje `core.js`) vs herní část (bytosti/questy/…, co si čte hra). `validate.mjs` ho vymáhá strojově (verze, operátory, efekty, cíle, duplicity). *Hotovo.*
5. **Genesis Studio** ✅ — IDE obal (`studio.html`): Director Console (chat/AI vlevo) + živý náhled hry (iframe, přepínatelné pohledy i hry) + inspektor souvislostí (Materiály/Zákony/**Souvislosti** = interaktivní graf „co s čím souvisí"/Nastavení+pluginy) vpravo. Změna přes AI konzoli hned obnoví náhled i inspektor. *Hotovo.*
6. **Provoz + SDK** — ✅ *hotovo:* single-file export teď balí i `core.js` (offline hra nespadne); Director Console hlásí, co věta smaže, a čeká na „Zapsat i tak" (diff-safety); ústava má časově verzovanou historii (`rules-historie/`). ⏳ *zbývá:* vlastní API klíč mimo n8n (`console.sh` už umí `GENESIS_KEY` z env); Desktop přes Tauri; otevřený JSON formát jako veřejná specifikace.

**CODEX = referenční implementace, ne hlavní produkt** (jako Quake pro id Tech). Funkce se do něj přidávají proto, že rozšiřují platformu — ne kvůli jedné hře. Ale musí zůstat dost dobrá hra, aby po enginu vznikla poptávka.

---

## Byznys model — SaaS, ne royalties

Žádný podíl z tržeb cizích her (nevymahatelné, a nejsi Epic). Místo toho:

- **Genesis Community Edition** — zdarma, lokální AI (Ollama), offline. Plný engine.
- **Genesis Cloud** — měsíční předplatné: hostovaná AI konzole, sandbox, verzování, spolupráce, publishing.

Předplatné je předvídatelné; royalties nejsou. Provoz financuje Cloud, ne mýto od tvůrců.

---

## Nesmí se rozjet do stran

Web / Desktop / SDK jsou **obaly kolem jednoho jádra.** Nová funkce se přidává do `core.js` + formátu ústavy, ne do obalu — jinak se z jednoho enginu stanou tři různé produkty. Každá změna jádra se testuje proti všem presetům (CODEX i Ekosystém), headless.

---

---

## AI vrstva & assety (multi-modal orchestrace)

**`ai.js` — client-side orchestrátor (BYOK).** Žádný sdílený server ani klíč. Každý uživatel má vlastní klíče (v prohlížeči), volání jdou přímo od něj. Modality jako pluginy: **text** (Claude/GPT/Gemini/DeepSeek), **obrázek** (Imagen/DALL·E/Stability), **hlas** (OpenAI TTS/ElevenLabs); hudba/video připraveny. Workflow = řetěz kroků (výstup → vstup dalšího přes `{{proměnná}}`), jako n8n, ale zabudované.

**CORS / distribuce:** ve webu jdou přímo jen Anthropic + Google. Ostatní blokuje prohlížeč → **Tauri desktop** (nativní HTTP bez CORS) odemkne všechny providery a drží vše u uživatele. `ai.js` pozná `window.__TAURI__` a přepne.

**`assets.js` — úložiště vygenerovaných/vlastních assetů** (IndexedDB, offline). Klíčováno jménem: `mat:lava`, `bytost:Drak`, `model:Drak`. Renderery se ptají „mám asset?" → textura/portrét, jinak barva/emoji z ústavy. Ústava tak nemusí vědět o grafice. Obrázky funkční ve 2D; z AI Orchestrátoru („Ulož do hry") i ručním uploadem.

### Blender workflow (3D modely + animace) — plán
1. Model + animace v **Blenderu** (zdarma), export do **glTF/`.glb`** (otevřený formát).
2. Nahrát v AI Orchestrátoru pod klíčem `model:Drak` → uloží se do `assets.js`.
3. *(zbývá)* 3D renderer načte glTF přes `GLTFLoader` a přehraje animace přes `AnimationMixer` — vyžaduje **migraci `index3d.html` z UMD three na ES moduly** (r149 už UMD loadery nemá). Do té doby procedurální modely z kvádrů/koulí.
4. Animace: CMU Motion Capture (zdarma) → doladit v Blenderu → aplikovat na model.

*Řídící dokument. Aktualizovat po každém dokončeném kroku roadmapy.*

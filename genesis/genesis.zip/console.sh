#!/bin/sh
# Spustí GENESIS Director Console s API klíčem vytaženým z n8n na VPS.
# Klíč žije jen v paměti tohoto procesu — nikam se nezapisuje.
cd "$(dirname "$0")"

VPS=root@89.167.123.58
ENC=$(ssh $VPS "docker exec roman-storage-n8n-1 cat /home/node/.n8n/config" | python3 -c "import json,sys; print(json.load(sys.stdin)['encryptionKey'])")

# Anthropic (Claude) je default; pro OpenAI dej CRED=6OsaZs6diYbdzait PROVIDER=openai
CRED=${CRED:-YHY28eQ9Y8we1r4X}
export GENESIS_PROVIDER=${PROVIDER:-anthropic}
export GENESIS_KEY=$(ssh $VPS "sqlite3 /var/lib/docker/volumes/roman-storage_n8n_data/_data/database.sqlite \"SELECT data FROM credentials_entity WHERE id='$CRED';\"" \
  | openssl enc -d -aes-256-cbc -md md5 -A -a -pass pass:"$ENC" \
  | python3 -c "import json,sys; print(json.load(sys.stdin)['apiKey'])")

if [ -z "$GENESIS_KEY" ]; then echo "Nepodařilo se získat klíč."; exit 1; fi
echo "Klíč načten (${GENESIS_KEY%${GENESIS_KEY#??????????????}}…), spouštím konzoli…"
exec node console-server.mjs

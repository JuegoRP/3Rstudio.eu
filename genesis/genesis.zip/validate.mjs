// Validátor ústavy: dostane rules.json na stdin, spustí svět nasucho na 60 tiků
// se stubem prohlížeče a ohlásí, jestli je hratelný. Toto je ta pojistka,
// kvůli které může netechnik měnit svět, aniž by si ho rozbil.
import fs from "fs";

let vstup = "";
process.stdin.on("data", d => vstup += d);
process.stdin.on("end", () => {
  const chyby = [], varovani = [];
  let data;
  try { data = JSON.parse(vstup); }
  catch (e) { hotovo(["Neplatný JSON: " + e.message], []); return; }

  // --- kontrola dle Constitution Specification ---
  const RUNTIME_VERZE = 2;
  if (data.schema_verze && data.schema_verze > RUNTIME_VERZE)
    chyby.push("schema_verze " + data.schema_verze + " je novější, než runtime umí (" + RUNTIME_VERZE + ").");

  // povinné sekce
  for (const klic of ["materialy", "zakony"]) {
    if (!data[klic]) chyby.push("Chybí povinná sekce \"" + klic + "\".");
  }
  if (chyby.length) return hotovo(chyby, varovani);

  // materiály: barva a vlastnosti ve správném tvaru
  for (const k in data.materialy) {
    const m = data.materialy[k];
    if (m.barva && !/^#[0-9a-fA-F]{6}$/.test(m.barva)) varovani.push("Materiál \"" + k + "\": barva není #rrggbb.");
    if (m.vlastnosti && !Array.isArray(m.vlastnosti)) chyby.push("Materiál \"" + k + "\": vlastnosti musí být pole.");
  }

  // zákony: struktura dle spec A.2–A.4
  const matKlice = new Set(Object.keys(data.materialy));
  const OPERATORY = new Set([">=", "<=", ">", "<", "="]);
  const EFEKTY = new Set(["pridejStav", "odeberStav", "zmenVar", "nastavVar", "promenNa", "log", "strop", "dno"]);
  const vidId = new Set();
  for (const z of data.zakony || []) {
    const kde = "Zákon \"" + (z.id || "?") + "\"";
    if (!z.id) chyby.push(kde + ": chybí id.");
    else if (vidId.has(z.id)) chyby.push(kde + ": duplicitní id."); else vidId.add(z.id);
    if (z.cil !== undefined && z.cil !== "sam" && z.cil !== "soused") chyby.push(kde + ": cil musí být 'sam' nebo 'soused'.");
    if (z.cil === "soused" && !z.pokud) varovani.push(kde + ": cil 'soused' bez 'pokud' (efekt na všechny sousedy).");
    if (z.sance !== undefined && (typeof z.sance !== "number" || z.sance < 0 || z.sance > 1)) chyby.push(kde + ": sance musí být 0–1.");
    if (!Array.isArray(z.udelej)) { chyby.push(kde + ": 'udelej' musí být pole efektů."); continue; }
    // operátory v podmínkách
    for (const pod of [z.kdyz, z.pokud]) {
      if (pod && pod.var) for (const jm in pod.var) for (const op in pod.var[jm])
        if (!OPERATORY.has(op)) chyby.push(kde + ": neznámý operátor '" + op + "' (povolené: >= <= > < =).");
    }
    for (const ef of z.udelej) {
      for (const key in ef) if (!EFEKTY.has(key)) varovani.push(kde + ": neznámý efekt '" + key + "'.");
      if (ef.promenNa && !matKlice.has(ef.promenNa)) varovani.push(kde + " mění na neznámý materiál \"" + ef.promenNa + "\".");
    }
  }
  for (const typ in (data.bytosti || {})) {
    for (const k of (data.bytosti[typ].lovi || []))
      if (k !== "hrdina" && !data.bytosti[k])
        varovani.push("Bytost \"" + typ + "\" loví neznámý druh \"" + k + "\".");
  }

  // dynamický běh: sim.js se stubem prohlížeče
  try {
    globalThis.window = { addEventListener() {} };
    const elStub = () => ({ innerHTML: "", style: {}, dataset: {}, classList: { toggle() {}, add() {}, remove() {} }, children: [], prepend() {}, removeChild() {}, appendChild() {}, addEventListener() {}, querySelectorAll: () => [] });
    globalThis.document = { getElementById: elStub, createElement: elStub, querySelectorAll: () => [] };
    globalThis.fetch = async () => ({ text: async () => vstup });
    globalThis.requestAnimationFrame = () => {};
    globalThis.setInterval = () => 0;
    globalThis.setTimeout = () => 0;

    // jádro + hra; strip "use strict", ať funkce po nepřímém evalu žijí v global scope
    const jadro = fs.readFileSync(new URL("./core.js", import.meta.url), "utf8").replace('"use strict";', "");
    const kod = fs.readFileSync(new URL("./sim.js", import.meta.url), "utf8").replace('"use strict";', "");
    (0, eval)(jadro + "\n" + kod);

    globalThis.nactiPravidla(true).then(() => {
      globalThis.generujSvet();
      const t0 = Date.now();
      for (let i = 0; i < 60; i++) {
        globalThis.krokSimulace();
        if (Date.now() - t0 > 4000) { chyby.push("Svět je příliš pomalý (možná nekonečná smyčka pravidel)."); break; }
      }
      // je svět „živý"? posbírej, kolik zákonů reálně působilo
      hotovo(chyby, varovani, {
        zakony: (data.zakony || []).length,
        materialy: matKlice.size,
        bytosti: Object.keys(data.bytosti || {}).length,
        questy: (data.questy || []).length
      });
    }).catch(e => hotovo(["Svět spadl při spuštění: " + e.message], varovani));
  } catch (e) {
    hotovo(["Chyba při načítání pravidel: " + e.message], varovani);
  }
});

function hotovo(chyby, varovani, souhrn) {
  process.stdout.write(JSON.stringify({ ok: chyby.length === 0, chyby, varovani, souhrn: souhrn || null }));
  process.exit(0);
}
